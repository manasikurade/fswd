/**
 * ============================================================
 * Experiment No.: 10
 * Title        : Demonstrate CRUD Operations on MongoDB
 * Purpose      : Connect to MongoDB and perform Create, Read,
 *                Update, Delete operations using Express.js
 *                and the MongoDB Node.js driver.
 * Technologies : Node.js, Express.js, MongoDB, Mongoose
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. Install MongoDB Community Server (https://www.mongodb.com/try/download/community)
 *   2. Start MongoDB service:
 *         Windows : net start MongoDB   OR open MongoDB Compass
 *         Mac/Linux: sudo systemctl start mongod
 *   3. cd Experiment-10/myapp
 *   4. npm install
 *   5. node index.js
 *   6. Test with Postman at http://localhost:3000
 * ============================================================
 * MONGOOSE vs RAW MONGODB DRIVER:
 *   This file uses MONGOOSE (ODM) for a cleaner, schema-based
 *   approach. Raw MongoDB driver examples are also shown in
 *   comments for reference.
 * ============================================================
 */

const express  = require('express');
const mongoose = require('mongoose');
const app      = express();
const PORT     = 3000;

// ── Middleware ─────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Request Logger ─────────────────────────────────────────
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ══════════════════════════════════════════════════════════
// STEP 1 – MONGOOSE SCHEMA & MODEL
// Defines the structure (schema) for a Student document.
// ══════════════════════════════════════════════════════════
const studentSchema = new mongoose.Schema(
  {
    name  : { type: String, required: [true, 'Name is required'],  trim: true },
    email : { type: String, required: [true, 'Email is required'], unique: true, lowercase: true, trim: true },
    branch: { type: String, required: [true, 'Branch is required'], enum: ['CSE', 'IT', 'MECH', 'CIVIL', 'ELECTRICAL', 'TEXTILE'] },
    marks : { type: Number, min: 0, max: 100, default: 0 },
    year  : { type: Number, enum: [1, 2, 3, 4], default: 1 },
    phone : { type: String, match: [/^[0-9]{10}$/, 'Enter valid 10-digit phone number'] },
  },
  {
    timestamps: true   // auto-adds createdAt and updatedAt fields
  }
);

// Virtual field – grade computed from marks
studentSchema.virtual('grade').get(function () {
  if (this.marks >= 90) return 'A+';
  if (this.marks >= 75) return 'A';
  if (this.marks >= 60) return 'B';
  if (this.marks >= 45) return 'C';
  return 'F';
});

// Model (compiled from schema)
const Student = mongoose.model('Student', studentSchema);

// ══════════════════════════════════════════════════════════
// STEP 2 – CONNECT TO MONGODB
// ══════════════════════════════════════════════════════════
const MONGO_URI = 'mongodb://localhost:27017/tei_lab_db';

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB at:', MONGO_URI);
    seedDatabase();   // add sample data on first run
  })
  .catch(err => {
    console.error('❌ MongoDB connection failed:', err.message);
    console.error('   Make sure MongoDB is running on port 27017.');
    console.error('   Start with: net start MongoDB (Windows)');
    console.error('              sudo systemctl start mongod (Linux/Mac)');
    process.exit(1);
  });

// Seed function – adds sample students if collection is empty
async function seedDatabase() {
  try {
    const count = await Student.countDocuments();
    if (count === 0) {
      await Student.insertMany([
        { name: 'Alice Sharma',  email: 'alice@tei.ac.in',  branch: 'CSE',  marks: 92, year: 3, phone: '9876543210' },
        { name: 'Bob Patil',     email: 'bob@tei.ac.in',    branch: 'IT',   marks: 78, year: 2, phone: '9988776655' },
        { name: 'Carol Kulkarni',email: 'carol@tei.ac.in',  branch: 'MECH', marks: 85, year: 4, phone: '8877665544' },
        { name: 'Dave Jadhav',   email: 'dave@tei.ac.in',   branch: 'CIVIL',marks: 60, year: 1, phone: '7766554433' },
        { name: 'Eve Desai',     email: 'eve@tei.ac.in',    branch: 'CSE',  marks: 95, year: 3, phone: '6655443322' },
      ]);
      console.log('🌱 Sample data seeded into MongoDB.');
    }
  } catch (err) {
    console.log('Seed skipped (data may already exist):', err.message);
  }
}

// ══════════════════════════════════════════════════════════
// ROUTES
// ══════════════════════════════════════════════════════════

/**
 * GET /
 * Welcome page with endpoint documentation
 */
app.get('/', (req, res) => {
  res.json({
    message    : '📚 Experiment 10 – MongoDB CRUD with Express & Mongoose',
    institute  : 'TEI Ichalkaranji',
    database   : 'tei_lab_db',
    collection : 'students',
    endpoints  : {
      'GET    /students'        : 'Get all students (supports ?branch=CSE&year=3)',
      'POST   /students'        : 'Create a new student',
      'GET    /students/:id'    : 'Get student by MongoDB _id',
      'PUT    /students/:id'    : 'Update student by _id',
      'DELETE /students/:id'    : 'Delete student by _id',
      'GET    /students/stats'  : 'Get aggregate statistics',
      'GET    /health'          : 'Server + DB health check',
    }
  });
});

// ──────────────────────────────────────────────────────────
// C – CREATE: POST /students
// ──────────────────────────────────────────────────────────
/**
 * POST /students
 * Create a new student document in MongoDB.
 * Body (JSON): { name, email, branch, marks, year, phone }
 *
 * Raw MongoDB equivalent:
 *   await collection.insertOne({ name, email, branch, marks });
 */
app.post('/students', async (req, res) => {
  try {
    const student = new Student(req.body);   // create document instance
    const saved   = await student.save();    // save to MongoDB

    res.status(201).json({
      success: true,
      message: 'Student created successfully!',
      data   : saved
    });
  } catch (err) {
    // Handle validation errors and duplicate key errors
    if (err.name === 'ValidationError') {
      const errors = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ success: false, error: 'Validation failed', details: errors });
    }
    if (err.code === 11000) {
      return res.status(400).json({ success: false, error: 'Email already exists.' });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// ──────────────────────────────────────────────────────────
// R – READ: GET /students and GET /students/:id
// ──────────────────────────────────────────────────────────

/**
 * GET /students
 * Retrieve all students. Supports optional query filters:
 *   ?branch=CSE    → filter by branch
 *   ?year=3        → filter by year
 *   ?sort=marks    → sort by field (default: name)
 *
 * Raw MongoDB equivalent:
 *   await collection.find({}).toArray();
 */
app.get('/students', async (req, res) => {
  try {
    const filter = {};
    if (req.query.branch) filter.branch = req.query.branch.toUpperCase();
    if (req.query.year)   filter.year   = parseInt(req.query.year);

    const sortField = req.query.sort || 'name';
    const students  = await Student.find(filter).sort(sortField);

    res.json({
      success: true,
      count  : students.length,
      filters: filter,
      data   : students
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /students/stats
 * Aggregated statistics – must be BEFORE /students/:id
 *
 * Raw MongoDB equivalent:
 *   await collection.aggregate([...]).toArray();
 */
app.get('/students/stats', async (req, res) => {
  try {
    const stats = await Student.aggregate([
      {
        $group: {
          _id      : '$branch',
          count    : { $sum: 1 },
          avgMarks : { $avg: '$marks' },
          maxMarks : { $max: '$marks' },
          minMarks : { $min: '$marks' }
        }
      },
      { $sort: { avgMarks: -1 } }
    ]);

    const total   = await Student.countDocuments();
    const topStudent = await Student.findOne().sort({ marks: -1 });

    res.json({
      success    : true,
      totalStudents: total,
      topStudent : topStudent ? { name: topStudent.name, marks: topStudent.marks } : null,
      branchStats: stats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /students/:id
 * Get a single student by MongoDB _id
 *
 * Raw MongoDB equivalent:
 *   const { ObjectId } = require('mongodb');
 *   await collection.findOne({ _id: new ObjectId(id) });
 */
app.get('/students/:id', async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);

    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found.' });
    }

    res.json({ success: true, data: student });
  } catch (err) {
    if (err.name === 'CastError') {
      return res.status(400).json({ success: false, error: 'Invalid MongoDB ID format.' });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// ──────────────────────────────────────────────────────────
// U – UPDATE: PUT /students/:id
// ──────────────────────────────────────────────────────────
/**
 * PUT /students/:id
 * Update a student's data by _id.
 * Only fields sent in body are updated (partial update).
 *
 * Raw MongoDB equivalent:
 *   await collection.updateOne(
 *     { _id: new ObjectId(id) },
 *     { $set: req.body }
 *   );
 */
app.put('/students/:id', async (req, res) => {
  try {
    const updated = await Student.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },           // only update provided fields
      { new: true, runValidators: true }  // return updated doc + validate
    );

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Student not found.' });
    }

    res.json({
      success: true,
      message: 'Student updated successfully!',
      data   : updated
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const errors = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ success: false, error: 'Validation failed', details: errors });
    }
    if (err.name === 'CastError') {
      return res.status(400).json({ success: false, error: 'Invalid MongoDB ID format.' });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// ──────────────────────────────────────────────────────────
// D – DELETE: DELETE /students/:id
// ──────────────────────────────────────────────────────────
/**
 * DELETE /students/:id
 * Remove a student document from MongoDB by _id.
 *
 * Raw MongoDB equivalent:
 *   await collection.deleteOne({ _id: new ObjectId(id) });
 */
app.delete('/students/:id', async (req, res) => {
  try {
    const deleted = await Student.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Student not found.' });
    }

    res.json({
      success: true,
      message: 'Student deleted successfully!',
      data   : deleted
    });
  } catch (err) {
    if (err.name === 'CastError') {
      return res.status(400).json({ success: false, error: 'Invalid MongoDB ID format.' });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// ──────────────────────────────────────────────────────────
// HEALTH CHECK
// ──────────────────────────────────────────────────────────
app.get('/health', async (req, res) => {
  const dbState = ['disconnected', 'connected', 'connecting', 'disconnecting'];
  const count   = await Student.countDocuments().catch(() => 'error');
  res.json({
    server  : 'running',
    database: dbState[mongoose.connection.readyState],
    dbName  : mongoose.connection.name,
    students: count
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, error: `Route ${req.method} ${req.path} not found.` });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(500).json({ success: false, error: 'Internal Server Error', details: err.message });
});

// ══════════════════════════════════════════════════════════
// START SERVER
// ══════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log('═══════════════════════════════════════════════════════');
  console.log('  Experiment 10 – CRUD Operations on MongoDB');
  console.log(`  Server : http://localhost:${PORT}`);
  console.log(`  DB URI : ${MONGO_URI}`);
  console.log('═══════════════════════════════════════════════════════');
  console.log('  Endpoints:');
  console.log(`    GET    http://localhost:${PORT}/students`);
  console.log(`    POST   http://localhost:${PORT}/students`);
  console.log(`    GET    http://localhost:${PORT}/students/:id`);
  console.log(`    PUT    http://localhost:${PORT}/students/:id`);
  console.log(`    DELETE http://localhost:${PORT}/students/:id`);
  console.log(`    GET    http://localhost:${PORT}/students/stats`);
  console.log('═══════════════════════════════════════════════════════');
});
