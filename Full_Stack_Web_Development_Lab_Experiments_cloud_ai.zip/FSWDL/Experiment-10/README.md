# Experiment 10 – CRUD Operations on MongoDB

## Aim
Demonstrate Create, Read, Update, and Delete (CRUD) operations on MongoDB using Express.js and Mongoose ODM.

## Technologies
- Node.js, Express.js, MongoDB, Mongoose, Postman

## Prerequisites
1. **Install MongoDB Community Server**
   - Download: https://www.mongodb.com/try/download/community
   - Start MongoDB service:
     ```bash
     # Windows
     net start MongoDB
     # OR open MongoDB Compass (GUI tool)

     # Linux/Mac
     sudo systemctl start mongod
     ```
2. **Verify MongoDB is running** on port `27017`

## Setup & Run

```bash
cd Experiment-10/myapp
npm install
node index.js
# Server: http://localhost:3000
# DB:     mongodb://localhost:27017/tei_lab_db
```

> ✅ Sample student data is **automatically seeded** on first run.

## API Endpoints – Test with Postman

### CREATE – POST /students
**URL:** `POST http://localhost:3000/students`  
**Headers:** `Content-Type: application/json`  
**Body:**
```json
{
  "name": "Ravi Kumar",
  "email": "ravi@tei.ac.in",
  "branch": "CSE",
  "marks": 88,
  "year": 2,
  "phone": "9876543211"
}
```

### READ ALL – GET /students
```
GET http://localhost:3000/students
GET http://localhost:3000/students?branch=CSE
GET http://localhost:3000/students?year=3
GET http://localhost:3000/students?sort=marks
```

### READ ONE – GET /students/:id
```
GET http://localhost:3000/students/64abc123def456789...
```
*(Copy `_id` from GET all response)*

### UPDATE – PUT /students/:id
**URL:** `PUT http://localhost:3000/students/:id`  
**Body:**
```json
{
  "marks": 95,
  "year": 3
}
```

### DELETE – DELETE /students/:id
```
DELETE http://localhost:3000/students/:id
```

### STATS – GET /students/stats
```
GET http://localhost:3000/students/stats
```

### HEALTH CHECK
```
GET http://localhost:3000/health
```

## Mongoose Schema
```js
const studentSchema = new mongoose.Schema({
  name  : { type: String, required: true },
  email : { type: String, required: true, unique: true },
  branch: { type: String, enum: ['CSE','IT','MECH','CIVIL','ELECTRICAL','TEXTILE'] },
  marks : { type: Number, min: 0, max: 100 },
  year  : { type: Number, enum: [1, 2, 3, 4] },
  phone : { type: String }
}, { timestamps: true });
```

## Raw MongoDB Driver Equivalents
```js
// Insert
await collection.insertOne(document);

// Find all
await collection.find({}).toArray();

// Find one
await collection.findOne({ _id: new ObjectId(id) });

// Update
await collection.updateOne({ _id: new ObjectId(id) }, { $set: data });

// Delete
await collection.deleteOne({ _id: new ObjectId(id) });
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `MongoDB connection failed` | Start MongoDB service first |
| `ECONNREFUSED 127.0.0.1:27017` | MongoDB not running |
| `Cast to ObjectId failed` | Use correct `_id` from DB |
| `E11000 duplicate key` | Email already exists in DB |

## Viva Questions
1. What is MongoDB? → NoSQL document database storing JSON-like BSON documents.
2. What is Mongoose? → ODM (Object Data Modeling) library for MongoDB in Node.js.
3. What is a Schema in Mongoose? → Blueprint defining the structure and validation of documents.
4. What is a Model? → A compiled version of the schema used to interact with the collection.
5. What does `{ timestamps: true }` do? → Auto-adds `createdAt` and `updatedAt` fields.
6. What is `findByIdAndUpdate`? → Mongoose method to find a document by `_id` and update it.
7. NoSQL vs SQL? → NoSQL: flexible schema, document-based; SQL: fixed schema, table-based.
