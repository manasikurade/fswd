# Experiment 02 – Create a Simple Web App Using Angular

## Aim
To explain the different basic building blocks of an Angular application and create a simple web app.

## Technologies Used
- Angular 17+, Angular CLI, TypeScript, HTML, CSS, Node.js

## Folder Structure
```
Experiment-02/
└── my-angular-app/
    ├── src/
    │   ├── app/
    │   │   ├── app.component.ts    ← Root component logic
    │   │   ├── app.component.html  ← Root template
    │   │   ├── app.component.css   ← Component styles
    │   │   ├── app.config.ts       ← App configuration
    │   │   └── app.routes.ts       ← Route definitions
    │   ├── main.ts                 ← Entry point
    │   ├── index.html              ← Host HTML page
    │   └── styles.css              ← Global styles
    ├── angular.json
    ├── package.json
    ├── tsconfig.json
    └── tsconfig.app.json
```

## Setup & Run in VS Code

```bash
# Step 1: Install Angular CLI globally (once only)
npm install -g @angular/cli

# Step 2: Navigate into the project folder
cd Experiment-02/my-angular-app

# Step 3: Install project dependencies
npm install

# Step 4: Start the development server
ng serve

# Step 5: Open in browser
# http://localhost:4200
```

## Expected Output
A styled Angular page showing:
- College/department header
- Angular logo and app title
- List of Angular key features (rendered using *ngFor)
- Angular project structure table

## Viva Questions
1. What is Angular? → Open-source frontend framework by Google for building SPAs.
2. What is Angular CLI? → Command-line tool to create, build, and serve Angular apps.
3. What is a component? → Building block of Angular — has TS logic, HTML template, CSS styles.
4. What is `selector`? → Custom HTML tag used to render a component in templates.
5. What is `standalone: true`? → Component that doesn't need NgModule declaration.
