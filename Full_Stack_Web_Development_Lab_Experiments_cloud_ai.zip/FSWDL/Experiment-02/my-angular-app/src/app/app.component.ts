/**
 * ============================================================
 * Experiment No.: 02
 * Title        : Create a simple web app using Angular
 * Purpose      : Understand Angular project structure, components,
 *                and how Angular renders a basic UI.
 * Technologies : Angular 17+, Angular CLI, TypeScript, HTML, CSS
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. Open VS Code and open folder: Experiment-02/my-angular-app
 *   2. Open integrated terminal (Ctrl + `)
 *   3. Install dependencies:
 *         npm install
 *   4. Start the development server:
 *         ng serve
 *   5. Open browser at: http://localhost:4200
 * ============================================================
 * EXTRA SETUP:
 *   - Install Node.js (https://nodejs.org)
 *   - Install Angular CLI: npm install -g @angular/cli
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',        // HTML tag used to render this component
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // Component Properties
  title = 'My First Angular App';
  collegeName = 'Textile and Engineering Institute, Ichalkaranji';
  department = 'Department of Computer Science & Engineering';
  subject = 'Full Stack Web Development Lab';
  experimentNo = '02';

  // Array of Angular features to display in the view
  features: string[] = [
    'Component-Based Architecture',
    'Two-Way Data Binding',
    'Dependency Injection',
    'Directives (ngIf, ngFor, ngSwitch)',
    'Routing Module',
    'Services',
    'HTTP Client',
    'Forms (Template-driven & Reactive)'
  ];

  // Current year for footer
  currentYear: number = new Date().getFullYear();
}
