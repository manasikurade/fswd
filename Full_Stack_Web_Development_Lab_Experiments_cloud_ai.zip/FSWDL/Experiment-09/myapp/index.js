/**
 * ============================================================
 * Experiment No.: 09
 * Title        : Demonstrate Middlewares in Express.js
 * Purpose      : Understand and implement various types of
 *                Express middlewares – application-level,
 *                router-level, error-handling, and built-in.
 * Technologies : Node.js, Express.js
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. cd Experiment-09/myapp
 *   2. npm install
 *   3. node index.js
 *   4. Test with Postman at http://localhost:3000
 * ============================================================
 */

const express = require('express');
const fs      = require('fs');
const path    = require('path');
const app     = express();
const PORT    = 3000;

// ── Built-in Middlewares ───────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 1 – myLogger (from lab manual)
// Logs "LOGGED" for every request
// ══════════════════════════════════════════════════════════
const myLogger = function (req, res, next) {
  console.log(`[LOGGED] ${req.method} ${req.path} @ ${new Date().toISOString()}`);
  next();   // Must call next() to continue to next middleware/route
};

app.use(myLogger);  // Apply globally BEFORE routes

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 2 – requestTime (from lab manual)
// Adds requestTime property to req object
// ══════════════════════════════════════════════════════════
const requestTime = function (req, res, next) {
  req.requestTime = new Date().toLocaleString();
  next();
};

app.use(requestTime);

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 3 – File Logger
// Writes request log to requests.log file
// ══════════════════════════════════════════════════════════
const fileLogger = function (req, res, next) {
  const logEntry = `[${new Date().toISOString()}] ${req.method} ${req.path} - IP: ${req.ip}\n`;
  fs.appendFile(path.join(__dirname, 'requests.log'), logEntry, (err) => {
    if (err) console.error('Log write error:', err);
  });
  next();
};

app.use(fileLogger);

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 4 – Auth Middleware (Route-Level)
// Applied only to specific protected routes
// ══════════════════════════════════════════════════════════
const authMiddleware = function (req, res, next) {
  const token = req.headers['authorization'];
  if (token && token === 'Bearer mytoken123') {
    req.user = { name: 'Admin', role: 'admin' };
    next();
  } else {
    res.status(401).json({
      success: false,
      error  : 'Unauthorized! Send header: Authorization: Bearer mytoken123'
    });
  }
};

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 5 – Request Validator (Route-Level)
// ══════════════════════════════════════════════════════════
const validateUserBody = function (req, res, next) {
  const { name, email } = req.body;
  if (!name || !email) {
    return res.status(400).json({
      success: false,
      error  : 'Validation failed: name and email are required in request body.'
    });
  }
  next();
};

// ══════════════════════════════════════════════════════════
// MIDDLEWARE 6 – Response Timer
// ══════════════════════════════════════════════════════════
const responseTimer = function (req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`[TIMER] ${req.method} ${req.path} → ${duration}ms | Status: ${res.statusCode}`);
  });
  next();
};

app.use(responseTimer);

// ══════════════════════════════════════════════════════════
// ROUTES
// ══════════════════════════════════════════════════════════

/**
 * GET /
 * Shows HTML page (demonstrates requestTime middleware)
 */
app.get('/', (req, res) => {
  let responseText = 'Hello World!<br>';
  responseText    += `<small>Requested at: ${req.requestTime}</small>`;

  res.send(`
    <html>
    <body style="font-family:sans-serif;padding:32px;background:#f5f5f5;">
      <h2>🚀 Experiment 09 – Express.js Middlewares</h2>
      <p>${responseText}</p>
      <h3>Active Middleware Stack:</h3>
      <ul>
        <li>✅ <b>myLogger</b> – logs each request method + path to console</li>
        <li>✅ <b>requestTime</b> – adds timestamp to req object</li>
        <li>✅ <b>fileLogger</b> – appends log entry to requests.log</li>
        <li>✅ <b>responseTimer</b> – measures and logs response time</li>
        <li>✅ <b>express.json()</b> – built-in JSON body parser</li>
      </ul>
      <h3>Test Endpoints (use Postman):</h3>
      <pre style="background:white;padding:16px;border-radius:8px;">
GET  http://localhost:3000/               → This page
GET  http://localhost:3000/api/info       → Request metadata
POST http://localhost:3000/api/echo       → Echo JSON body
POST http://localhost:3000/api/users      → Validated body (needs name+email)
GET  http://localhost:3000/api/protected  → Needs: Authorization: Bearer mytoken123
POST http://localhost:3000/api/login      → {"username":"admin","password":"admin123"}
GET  http://localhost:3000/api/slow       → 500ms delay – watch timer in console
      </pre>
    </body>
    </html>
  `);
});

/**
 * GET /api/info
 * Shows metadata added by middlewares
 */
app.get('/api/info', (req, res) => {
  res.json({
    success    : true,
    message    : 'Request metadata added by middlewares',
    requestTime: req.requestTime,
    method     : req.method,
    path       : req.path,
    ip         : req.ip,
    userAgent  : req.headers['user-agent']
  });
});

/**
 * POST /api/echo
 * Echoes back the parsed JSON body
 */
app.post('/api/echo', (req, res) => {
  res.json({
    success     : true,
    message     : 'Body echoed back (parsed by express.json() middleware)',
    receivedBody: req.body,
    requestTime : req.requestTime
  });
});

/**
 * POST /api/users
 * Route-level middleware: validateUserBody runs first
 */
app.post('/api/users', validateUserBody, (req, res) => {
  const { name, email, age } = req.body;
  res.status(201).json({
    success: true,
    message: 'Validation passed! User data received.',
    user   : { id: Math.floor(Math.random() * 1000), name, email, age }
  });
});

/**
 * GET /api/protected
 * Route-level middleware: authMiddleware runs first
 * Send header: Authorization: Bearer mytoken123
 */
app.get('/api/protected', authMiddleware, (req, res) => {
  res.json({
    success: true,
    message: '🔒 Protected resource accessed successfully!',
    user   : req.user,
    time   : req.requestTime
  });
});

/**
 * GET /api/slow
 * Artificial delay to demonstrate responseTimer middleware
 */
app.get('/api/slow', (req, res) => {
  setTimeout(() => {
    res.json({
      success: true,
      message: '⏳ This response had a 500ms delay – check console for timer output!'
    });
  }, 500);
});

/**
 * POST /api/login
 * Simulated login route
 */
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'admin123') {
    res.json({
      success: true,
      message: 'Login successful!',
      token  : 'Bearer mytoken123',
      hint   : 'Use this token in Authorization header to access /api/protected'
    });
  } else {
    res.status(401).json({
      success: false,
      error  : 'Invalid credentials. Try: username=admin password=admin123'
    });
  }
});

// ══════════════════════════════════════════════════════════
// ERROR-HANDLING MIDDLEWARE (must have 4 params)
// ══════════════════════════════════════════════════════════
app.use((err, req, res, next) => {
  console.error('[ERROR MIDDLEWARE]', err.message);
  res.status(500).json({
    success: false,
    error  : 'Internal Server Error',
    message: err.message
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error  : `Route ${req.method} ${req.path} not found.`
  });
});

// ══════════════════════════════════════════════════════════
// START SERVER
// ══════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log('══════════════════════════════════════════════════');
  console.log('  Experiment 09 – Express.js Middlewares');
  console.log(`  Server  : http://localhost:${PORT}`);
  console.log('  Middleware Stack: myLogger → requestTime →');
  console.log('                   fileLogger → responseTimer');
  console.log('══════════════════════════════════════════════════');
});
