# Experiment 09 – Middlewares in Express.js

## Aim
Demonstrate various types of Express.js middleware functions and their role in the request-response cycle.

## Middleware Types Implemented

| Middleware | Type | Purpose |
|-----------|------|---------|
| `myLogger` | Application-level | Logs every request to console |
| `requestTime` | Application-level | Adds timestamp to `req` object |
| `fileLogger` | Application-level | Writes logs to `requests.log` |
| `responseTimer` | Application-level | Measures request processing time |
| `authMiddleware` | Route-level | Token check on specific routes |
| `validateUserBody` | Route-level | Validates required body fields |
| `express.json()` | Built-in | Parses JSON request bodies |
| `(err,req,res,next)` | Error-handling | Catches and formats errors |

## Setup & Run

```bash
cd Experiment-09/myapp
npm install
node index.js
# Server at http://localhost:3000
```

## Postman Tests

| Method | URL | Notes |
|--------|-----|-------|
| GET | `http://localhost:3000/` | HTML welcome page |
| GET | `http://localhost:3000/api/info` | See req metadata from middlewares |
| POST | `http://localhost:3000/api/echo` | Send JSON body → echoed back |
| POST | `http://localhost:3000/api/users` | Needs `name` + `email` in body |
| GET | `http://localhost:3000/api/protected` | Header: `Authorization: Bearer mytoken123` |
| GET | `http://localhost:3000/api/slow` | 500ms delay – timer in console |
| POST | `http://localhost:3000/api/login` | Body: `{"username":"admin","password":"admin123"}` |

## Key Concept
```js
// Middleware signature
function myMiddleware(req, res, next) {
  // do something with req or res
  next();  // MUST call next() or request hangs!
}

// Apply globally (all routes)
app.use(myMiddleware);

// Apply to one route only
app.get('/secret', myMiddleware, (req, res) => { ... });

// Error-handling middleware (4 parameters!)
app.use((err, req, res, next) => {
  res.status(500).json({ error: err.message });
});
```

## Viva Questions
1. What is middleware? → A function with access to `req`, `res`, and `next` in request-response cycle.
2. Why must we call `next()`? → To pass control to the next middleware/handler; without it, request hangs.
3. What is order of middleware? → Top-to-bottom: first registered runs first.
4. What is error-handling middleware? → Has 4 params `(err, req, res, next)`; catches errors from routes.
5. Difference between app-level and route-level? → App-level runs for all routes; route-level only for specified route.
