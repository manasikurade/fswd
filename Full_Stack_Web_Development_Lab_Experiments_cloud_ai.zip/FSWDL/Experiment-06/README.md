# Experiment 06 – Page Routing in Angular

## Aim
Demonstrate Angular Router to navigate between multiple components based on the URL path without full page reloads.

## Components Created
| Component | Route | Description |
|-----------|-------|-------------|
| HomeComponent | `/home` | Landing page |
| AboutComponent | `/about` | Info page |
| ProductsComponent | `/products` | Product listing with cart |
| ContactComponent | `/contact` | Contact form |

## Setup & Run

```bash
cd Experiment-06/my-first-app
npm install
ng serve
# Open http://localhost:4200
```

## Key Concepts

```typescript
// 1. Define routes in app.routes.ts
{ path: 'home', component: HomeComponent }

// 2. Add routerLink in template
<a routerLink="/home" routerLinkActive="active">Home</a>

// 3. Add router-outlet in app template
<router-outlet></router-outlet>
```

## Key Notes
- `<router-outlet>` is a placeholder that Angular replaces with the matched component.
- `routerLinkActive="active"` adds the CSS class `active` to the current link.
- `{ path: '**', redirectTo: 'home' }` is the wildcard route (404 fallback).
- `redirectTo` with `pathMatch: 'full'` handles the empty URL redirect.

## Viva Questions
1. What is `<router-outlet>`? → Placeholder where Angular renders matched route's component.
2. What is `routerLink`? → Angular directive for SPA navigation (replaces `href`).
3. What is a wildcard route `**`? → Catches all unmatched paths; used for 404 pages.
4. What is `pathMatch: 'full'`? → Matches only when the entire URL equals the path.
