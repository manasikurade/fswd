import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Product {
  id: number; name: string; price: number; category: string; emoji: string;
}

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-card">
      <div class="page-header">
        <span class="icon">🛍️</span>
        <h1>Products</h1>
        <p>This is the <strong>Products Component</strong> at route <code>/products</code>.</p>
      </div>

      <div class="product-grid">
        <div class="product-card" *ngFor="let p of products">
          <div class="product-emoji">{{ p.emoji }}</div>
          <h3>{{ p.name }}</h3>
          <span class="category">{{ p.category }}</span>
          <div class="price">₹{{ p.price.toLocaleString() }}</div>
          <button class="add-btn" (click)="addToCart(p)">Add to Cart</button>
        </div>
      </div>

      <div class="cart-summary" *ngIf="cart.length > 0">
        <h3>🛒 Cart ({{ cart.length }} items)</h3>
        <ul>
          <li *ngFor="let item of cart">{{ item.emoji }} {{ item.name }} – ₹{{ item.price }}</li>
        </ul>
        <p class="total"><strong>Total: ₹{{ cartTotal.toLocaleString() }}</strong></p>
        <button class="clear-btn" (click)="cart=[]">Clear Cart</button>
      </div>
    </div>
  `,
  styles: [`
    .page-card { animation: fadeIn 0.4s ease; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; } }
    .page-header { background: white; border-radius: 16px; padding: 32px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 24px; }
    .icon { font-size: 2.5rem; display: block; margin-bottom: 8px; }
    h1 { color: #0d47a1; font-size: 1.7rem; margin-bottom: 8px; }
    p  { color: #666; } code { background: #e3f2fd; color: #0d47a1; padding: 2px 7px; border-radius: 4px; }
    .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .product-card { background: white; border-radius: 12px; padding: 24px; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,0.07); transition: transform 0.2s; }
    .product-card:hover { transform: translateY(-4px); }
    .product-emoji { font-size: 2.5rem; margin-bottom: 10px; }
    .product-card h3 { color: #0d47a1; margin-bottom: 6px; font-size: 0.95rem; }
    .category { font-size: 0.75rem; background: #e3f2fd; color: #1976d2; padding: 2px 10px; border-radius: 12px; }
    .price { font-size: 1.2rem; font-weight: 700; color: #1976d2; margin: 12px 0; }
    .add-btn { width: 100%; padding: 8px; background: #1976d2; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; transition: background 0.2s; }
    .add-btn:hover { background: #0d47a1; }
    .cart-summary { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); }
    .cart-summary h3 { color: #0d47a1; margin-bottom: 12px; }
    ul { list-style: none; padding: 0; }
    li { padding: 8px 0; border-bottom: 1px solid #f0f0f0; color: #555; font-size: 0.9rem; }
    .total { margin-top: 12px; color: #0d47a1; font-size: 1.05rem; }
    .clear-btn { margin-top: 12px; padding: 8px 20px; background: #ef5350; color: white; border: none; border-radius: 8px; cursor: pointer; }
  `]
})
export class ProductsComponent {
  products: Product[] = [
    { id: 1, name: 'Laptop',      price: 55000, category: 'Electronics', emoji: '💻' },
    { id: 2, name: 'Smartphone',  price: 25000, category: 'Electronics', emoji: '📱' },
    { id: 3, name: 'Headphones',  price: 4500,  category: 'Audio',       emoji: '🎧' },
    { id: 4, name: 'Keyboard',    price: 3200,  category: 'Accessories', emoji: '⌨️' },
    { id: 5, name: 'Mouse',       price: 1800,  category: 'Accessories', emoji: '🖱️' },
    { id: 6, name: 'Monitor',     price: 18000, category: 'Electronics', emoji: '🖥️' },
  ];

  cart: Product[] = [];

  addToCart(p: Product): void { this.cart.push(p); }

  get cartTotal(): number { return this.cart.reduce((s, p) => s + p.price, 0); }
}
