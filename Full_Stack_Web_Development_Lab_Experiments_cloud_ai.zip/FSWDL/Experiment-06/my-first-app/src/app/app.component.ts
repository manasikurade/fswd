/**
 * ============================================================
 * Experiment No.: 06
 * Title        : Demonstrate Page Routing in Angular
 * Purpose      : Navigate between multiple components using
 *                Angular Router with routerLink and router-outlet.
 * Technologies : Angular 17+, Angular Router
 * ============================================================
 * HOW TO RUN:
 *   cd Experiment-06/my-first-app && npm install && ng serve
 *   Visit: http://localhost:4200
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Routing Demo';
  isMenuOpen = false;
  toggleMenu() { this.isMenuOpen = !this.isMenuOpen; }
}
