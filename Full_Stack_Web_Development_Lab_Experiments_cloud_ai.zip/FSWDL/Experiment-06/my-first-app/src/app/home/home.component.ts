import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-card">
      <div class="hero">
        <div class="icon">🏠</div>
        <h1>Welcome to Our Angular App!</h1>
        <p>This is the <strong>Home Component</strong> rendered by Angular Router when the URL is <code>/home</code>.</p>
        <div class="cta-row">
          <a routerLink="/about"    class="btn">Learn About Us</a>
          <a routerLink="/products" class="btn btn-outline">View Products</a>
        </div>
      </div>

      <div class="features">
        <div class="feat-card" *ngFor="let f of features">
          <span class="feat-icon">{{ f.icon }}</span>
          <h3>{{ f.title }}</h3>
          <p>{{ f.desc }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-card { animation: fadeIn 0.4s ease; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
    .hero { background: white; border-radius: 16px; padding: 48px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 28px; }
    .icon { font-size: 3rem; margin-bottom: 12px; }
    h1 { font-size: 1.8rem; color: #0d47a1; margin-bottom: 12px; }
    p  { color: #666; font-size: 1rem; line-height: 1.6; }
    code { background: #e3f2fd; color: #0d47a1; padding: 2px 8px; border-radius: 4px; }
    .cta-row { display: flex; gap: 12px; justify-content: center; margin-top: 24px; flex-wrap: wrap; }
    .btn { padding: 12px 28px; background: #1976d2; color: white; border-radius: 8px; text-decoration: none; font-weight: 600; transition: all 0.2s; }
    .btn:hover { background: #0d47a1; transform: translateY(-2px); }
    .btn-outline { background: transparent; color: #1976d2; border: 2px solid #1976d2; }
    .btn-outline:hover { background: #1976d2; color: white; }
    .features { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
    .feat-card { background: white; border-radius: 12px; padding: 24px; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border-top: 4px solid #1976d2; }
    .feat-icon { font-size: 2rem; display: block; margin-bottom: 10px; }
    .feat-card h3 { color: #0d47a1; margin-bottom: 6px; font-size: 1rem; }
    .feat-card p  { color: #777; font-size: 0.85rem; line-height: 1.5; }
  `]
})
export class HomeComponent {
  features = [
    { icon: '🚀', title: 'Fast', desc: 'Built with Angular for blazing speed and performance.' },
    { icon: '🔒', title: 'Secure', desc: 'Security best practices built-in by default.' },
    { icon: '📱', title: 'Responsive', desc: 'Works perfectly on mobile, tablet, and desktop.' },
    { icon: '🧩', title: 'Modular', desc: 'Component-based architecture for reusability.' },
  ];
}
