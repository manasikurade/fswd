import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-card">
      <div class="page-header">
        <span class="icon">ℹ️</span>
        <h1>About Us</h1>
        <p>This is the <strong>About Component</strong> rendered at route <code>/about</code>.</p>
      </div>

      <div class="info-grid">
        <div class="info-block">
          <h2>🏫 About the Institute</h2>
          <p>Textile and Engineering Institute, Ichalkaranji is one of the premier engineering colleges in Maharashtra offering BE programs in Computer Science, IT, Mechanical, Civil and Textile Engineering.</p>
        </div>
        <div class="info-block">
          <h2>📚 About the Subject</h2>
          <p>Full Stack Web Development Lab covers modern web technologies including TypeScript, Angular (frontend), Node.js + Express (backend), and MongoDB (database).</p>
        </div>
        <div class="info-block">
          <h2>🎯 Experiment Goal</h2>
          <p>This experiment demonstrates how Angular Router enables Single Page Application (SPA) navigation — switching views without full page reloads.</p>
        </div>
        <div class="info-block">
          <h2>🔧 Technologies Used</h2>
          <ul>
            <li *ngFor="let t of tech">{{ t }}</li>
          </ul>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-card { animation: fadeIn 0.4s ease; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
    .page-header { background: white; border-radius: 16px; padding: 36px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 24px; }
    .icon { font-size: 2.5rem; display: block; margin-bottom: 8px; }
    h1 { color: #0d47a1; font-size: 1.7rem; margin-bottom: 8px; }
    p  { color: #666; line-height: 1.6; }
    code { background: #e3f2fd; color: #0d47a1; padding: 2px 7px; border-radius: 4px; }
    .info-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .info-block { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border-left: 5px solid #1976d2; }
    .info-block h2 { color: #0d47a1; margin-bottom: 10px; font-size: 1rem; }
    .info-block p  { color: #555; font-size: 0.9rem; line-height: 1.6; }
    ul { padding-left: 20px; color: #555; font-size: 0.9rem; line-height: 1.8; }
  `]
})
export class AboutComponent {
  tech = ['Angular 17+', 'TypeScript', 'Node.js', 'Express.js', 'MongoDB', 'HTML5 & CSS3'];
}
