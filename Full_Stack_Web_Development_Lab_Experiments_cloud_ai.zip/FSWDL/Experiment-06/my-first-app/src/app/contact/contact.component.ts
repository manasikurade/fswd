import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-card">
      <div class="page-header">
        <span class="icon">📬</span>
        <h1>Contact Us</h1>
        <p>This is the <strong>Contact Component</strong> at route <code>/contact</code>.</p>
      </div>

      <div class="contact-layout">
        <div class="contact-form">
          <h2>Send us a Message</h2>

          <div *ngIf="sent" class="success-msg">
            ✅ Thank you, <strong>{{ form.name }}</strong>! Your message has been sent.
          </div>

          <div *ngIf="!sent">
            <div class="form-group">
              <label>Your Name</label>
              <input [(ngModel)]="form.name" placeholder="Enter name" class="inp" />
            </div>
            <div class="form-group">
              <label>Email</label>
              <input [(ngModel)]="form.email" type="email" placeholder="Enter email" class="inp" />
            </div>
            <div class="form-group">
              <label>Message</label>
              <textarea [(ngModel)]="form.message" placeholder="Your message..." class="inp" rows="4"></textarea>
            </div>
            <button (click)="submit()" class="send-btn">Send Message 📨</button>
          </div>
        </div>

        <div class="contact-info">
          <h2>Contact Information</h2>
          <div class="info-item" *ngFor="let c of contacts">
            <span class="c-icon">{{ c.icon }}</span>
            <div><strong>{{ c.label }}</strong><br><span>{{ c.value }}</span></div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-card { animation: fadeIn 0.4s ease; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; } }
    .page-header { background: white; border-radius: 16px; padding: 32px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 24px; }
    .icon { font-size: 2.5rem; display: block; margin-bottom: 8px; }
    h1 { color: #0d47a1; font-size: 1.7rem; margin-bottom: 8px; }
    p  { color: #666; } code { background: #e3f2fd; color: #0d47a1; padding: 2px 7px; border-radius: 4px; }
    .contact-layout { display: grid; grid-template-columns: 3fr 2fr; gap: 20px; }
    @media (max-width: 640px) { .contact-layout { grid-template-columns: 1fr; } }
    .contact-form, .contact-info { background: white; border-radius: 12px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); }
    h2 { color: #0d47a1; margin-bottom: 20px; font-size: 1.1rem; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; font-weight: 600; color: #333; margin-bottom: 6px; font-size: 0.88rem; }
    .inp { width: 100%; padding: 10px 14px; border: 2px solid #bbdefb; border-radius: 8px; font-size: 0.95rem; outline: none; font-family: inherit; resize: vertical; }
    .inp:focus { border-color: #1976d2; }
    .send-btn { width: 100%; padding: 12px; background: #1976d2; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: background 0.2s; }
    .send-btn:hover { background: #0d47a1; }
    .success-msg { background: #e8f5e9; color: #2e7d32; border-left: 4px solid #43a047; padding: 16px; border-radius: 8px; }
    .info-item { display: flex; align-items: flex-start; gap: 14px; margin-bottom: 20px; }
    .c-icon { font-size: 1.5rem; }
    .info-item strong { color: #0d47a1; font-size: 0.9rem; }
    .info-item span   { color: #666; font-size: 0.88rem; }
  `]
})
export class ContactComponent {
  form = { name: '', email: '', message: '' };
  sent = false;

  submit(): void {
    if (this.form.name && this.form.email && this.form.message) {
      this.sent = true;
      console.log('Contact Form Submitted:', this.form);
    }
  }

  contacts = [
    { icon: '🏫', label: 'Institute',  value: 'Textile & Engineering Institute, Ichalkaranji' },
    { icon: '📧', label: 'Email',      value: 'info@tei.edu.in' },
    { icon: '📞', label: 'Phone',      value: '+91 98765 43210' },
    { icon: '🌐', label: 'Website',    value: 'www.tei.edu.in' },
    { icon: '📍', label: 'Location',   value: 'Ichalkaranji, Kolhapur, Maharashtra' },
  ];
}
