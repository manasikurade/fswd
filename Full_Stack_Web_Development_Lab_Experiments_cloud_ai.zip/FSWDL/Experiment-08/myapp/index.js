/**
 * ============================================================
 * Experiment No.: 08
 * Title        : Handling Routes in Express.js
 * Purpose      : Demonstrate how Express.js handles GET, POST,
 *                PUT, DELETE routes, route parameters, and
 *                multiple route handlers.
 * Technologies : Node.js, Express.js
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. Open VS Code → File → Open Folder → Experiment-08/myapp
 *   2. Open integrated terminal (Ctrl + `)
 *   3. Install dependencies:
 *         npm install
 *   4. Start the server:
 *         node index.js
 *   5. Use Postman or browser to test:
 *         GET  http://localhost:3000/
 *         GET  http://localhost:3000/users
 *         POST http://localhost:3000/users    (body: JSON)
 *         GET  http://localhost:3000/users/1
 *         PUT  http://localhost:3000/users/1  (body: JSON)
 *         DELETE http://localhost:3000/users/1
 * ============================================================
 * EXTRA SETUP:
 *   - Install Node.js (https://nodejs.org)
 *   - Install Postman (https://www.postman.com) for testing
 * ============================================================
 */

const express = require('express');
const app  = express();
const PORT = 3000;

// ── Middleware: parse JSON request bodies ──────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── In-memory data store (simulates a database) ────────────
let users = [
  { id: 1, name: 'Alice',  email: 'alice@example.com',  age: 22 },
  { id: 2, name: 'Bob',    email: 'bob@example.com',    age: 25 },
  { id: 3, name: 'Carol',  email: 'carol@example.com',  age: 28 },
];
let nextId = 4;

// ══════════════════════════════════════════════════════════
// SECTION 1 – BASIC ROUTES
// ══════════════════════════════════════════════════════════

/**
 * GET /
 * Root route – homepage response
 */
app.get('/', (req, res) => {
  res.json({
    message   : 'Welcome to Experiment 08 – Express Routing!',
    experiment: 'No. 08',
    institute : 'TEI Ichalkaranji',
    endpoints : {
      'GET  /'           : 'This welcome message',
      'GET  /users'      : 'Get all users',
      'POST /users'      : 'Create a new user',
      'GET  /users/:id'  : 'Get user by ID',
      'PUT  /users/:id'  : 'Update user by ID',
      'DELETE /users/:id': 'Delete user by ID',
      'GET  /search'     : 'Search users by query param ?name=...',
      'GET  /flights/:from-:to' : 'Route param with hyphen',
      'GET  /products/:category/:id' : 'Multiple route params',
    }
  });
});

/**
 * POST /
 * Respond to POST request on root route
 */
app.post('/', (req, res) => {
  res.json({ message: 'Got a POST request on root!', body: req.body });
});

// ══════════════════════════════════════════════════════════
// SECTION 2 – RESOURCE ROUTES (CRUD for /users)
// ══════════════════════════════════════════════════════════

/**
 * GET /users
 * Return all users
 */
app.get('/users', (req, res) => {
  res.json({
    success: true,
    count  : users.length,
    data   : users
  });
});

/**
 * POST /users
 * Create a new user
 * Body: { name, email, age }
 */
app.post('/users', (req, res) => {
  const { name, email, age } = req.body;

  // Basic validation
  if (!name || !email) {
    return res.status(400).json({ success: false, error: 'name and email are required.' });
  }

  const newUser = { id: nextId++, name, email, age: age || 0 };
  users.push(newUser);

  res.status(201).json({ success: true, message: 'User created!', data: newUser });
});

/**
 * GET /users/:id
 * Get a single user by ID
 * Route Parameter: :id
 */
app.get('/users/:id', (req, res) => {
  const id   = parseInt(req.params.id);
  const user = users.find(u => u.id === id);

  if (!user) {
    return res.status(404).json({ success: false, error: `User with id ${id} not found.` });
  }

  res.json({ success: true, data: user });
});

/**
 * PUT /users/:id
 * Update an existing user by ID
 * Body: { name?, email?, age? }
 */
app.put('/users/:id', (req, res) => {
  const id    = parseInt(req.params.id);
  const index = users.findIndex(u => u.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: `User with id ${id} not found.` });
  }

  // Merge existing user with incoming updates
  users[index] = { ...users[index], ...req.body, id };
  res.json({ success: true, message: 'User updated!', data: users[index] });
});

/**
 * DELETE /users/:id
 * Remove a user by ID
 */
app.delete('/users/:id', (req, res) => {
  const id    = parseInt(req.params.id);
  const index = users.findIndex(u => u.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: `User with id ${id} not found.` });
  }

  const deleted = users.splice(index, 1)[0];
  res.json({ success: true, message: 'User deleted!', data: deleted });
});

// ══════════════════════════════════════════════════════════
// SECTION 3 – ROUTE PARAMETERS (advanced examples)
// ══════════════════════════════════════════════════════════

/**
 * GET /search
 * Query parameters – /search?name=Alice&age=22
 */
app.get('/search', (req, res) => {
  const { name, age } = req.query;
  let results = [...users];

  if (name) results = results.filter(u => u.name.toLowerCase().includes(name.toLowerCase()));
  if (age)  results = results.filter(u => u.age === parseInt(age));

  res.json({
    success     : true,
    queryParams : req.query,
    count       : results.length,
    results
  });
});

/**
 * GET /flights/:from-:to
 * Route parameters with hyphen separator
 * Example: GET /flights/LAX-SFO
 */
app.get('/flights/:from-:to', (req, res) => {
  res.json({
    success : true,
    message : `Flight route demo`,
    from    : req.params.from,
    to      : req.params.to,
    example : 'GET /flights/MUM-DEL → from: MUM, to: DEL'
  });
});

/**
 * GET /products/:category/:id
 * Multiple route parameters
 * Example: GET /products/electronics/42
 */
app.get('/products/:category/:id', (req, res) => {
  res.json({
    success  : true,
    message  : 'Multiple route parameters demo',
    category : req.params.category,
    id       : req.params.id,
    fullParams: req.params
  });
});

/**
 * PUT /user
 * Respond to PUT request (from lab manual example)
 */
app.put('/user', (req, res) => {
  res.json({ message: 'Got a PUT request at /user', body: req.body });
});

/**
 * DELETE /user
 * Respond to DELETE request (from lab manual example)
 */
app.delete('/user', (req, res) => {
  res.json({ message: 'Got a DELETE request at /user' });
});

// ══════════════════════════════════════════════════════════
// SECTION 4 – MULTIPLE CALLBACKS (next() demo)
// ══════════════════════════════════════════════════════════

const logRequest  = (req, res, next) => { console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`); next(); };
const checkAuth   = (req, res, next) => { const auth = req.headers['x-auth']; if (auth === 'secret123') next(); else res.status(401).json({ error: 'Unauthorized – send header x-auth: secret123' }); };

/**
 * GET /protected
 * Route with multiple middleware callbacks
 * Requires header: x-auth: secret123
 */
app.get('/protected', logRequest, checkAuth, (req, res) => {
  res.json({ success: true, message: '🔒 Protected route accessed successfully!' });
});

// ══════════════════════════════════════════════════════════
// START SERVER
// ══════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log('═══════════════════════════════════════════════');
  console.log('  Experiment 08 – Express.js Routing');
  console.log(`  Server running at: http://localhost:${PORT}`);
  console.log('═══════════════════════════════════════════════');
  console.log('  Test endpoints with Postman or browser.');
  console.log('  Press Ctrl+C to stop the server.');
});
