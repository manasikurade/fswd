# Experiment 08 – Handling Routes in Express.js

## Aim
Demonstrate routing in Express.js to handle client requests based on HTTP method and URL path.

## Technologies
- Node.js, Express.js, npm, Postman

## Setup & Run

```bash
cd Experiment-08/myapp
npm install
node index.js
# Server starts at http://localhost:3000
```

## API Endpoints to Test in Postman

| Method | URL | Description |
|--------|-----|-------------|
| GET | `http://localhost:3000/` | Welcome message + endpoints list |
| GET | `http://localhost:3000/users` | Get all users |
| POST | `http://localhost:3000/users` | Create user (body: JSON) |
| GET | `http://localhost:3000/users/1` | Get user by ID |
| PUT | `http://localhost:3000/users/1` | Update user by ID |
| DELETE | `http://localhost:3000/users/1` | Delete user by ID |
| GET | `http://localhost:3000/search?name=Alice` | Search by query param |
| GET | `http://localhost:3000/flights/MUM-DEL` | Hyphenated route params |
| GET | `http://localhost:3000/products/electronics/42` | Multiple route params |
| GET | `http://localhost:3000/protected` | Protected route (add header `x-auth: secret123`) |

## Postman – POST Body Example
```json
{
  "name": "Dave",
  "email": "dave@example.com",
  "age": 30
}
```
Set **Content-Type: application/json** in Postman headers.

## Key Concepts
```js
// Route structure
app.METHOD(PATH, HANDLER)

// Route parameters
app.get('/users/:id', (req, res) => {
  console.log(req.params.id);   // from URL
});

// Query parameters
// GET /search?name=Alice
app.get('/search', (req, res) => {
  console.log(req.query.name);  // 'Alice'
});
```

## Viva Questions
1. What is Express.js? → Minimal Node.js web framework for building REST APIs.
2. What is `req.params`? → Object containing URL route parameters (`:id`).
3. What is `req.query`? → Object containing URL query parameters (`?key=value`).
4. What is `req.body`? → Parsed JSON body (requires `express.json()` middleware).
5. What does `next()` do? → Passes control to the next middleware/handler in the chain.
