# Full Stack Web Development Lab – All Experiments

**Department of Computer Science and Engineering**  
**Textile and Engineering Institute, Ichalkaranji**

---

## 📋 List of Experiments

| # | Title | Technologies |
|---|-------|-------------|
| 01 | TypeScript Programming Concepts | TypeScript, Node.js |
| 02 | Simple Web App Using Angular | Angular, Angular CLI |
| 03 | Data Binding & Event Binding in Angular | Angular |
| 04 | Form Development Using Angular | Angular, Reactive Forms |
| 05 | Structural Directives in Angular | Angular (ngIf, ngFor, ngSwitch) |
| 06 | Page Routing in Angular | Angular Router |
| 07 | Services in Angular | Angular Services, DI |
| 08 | Handling Routes in Express.js | Node.js, Express.js |
| 09 | Middlewares in Express.js | Node.js, Express.js |
| 10 | CRUD Operations on MongoDB | Node.js, Express.js, MongoDB |

---

## 🖥️ Common Setup Instructions

### Prerequisites
- **Node.js** (v18 or later) – https://nodejs.org
- **VS Code** – https://code.visualstudio.com
- **Postman** – https://www.postman.com (for Expt 08, 09, 10)
- **MongoDB Community Server** – https://www.mongodb.com/try/download/community (for Expt 10)

### Install Node.js
```bash
# Verify installation
node -v
npm -v
```

### Install Angular CLI (for Experiments 02–07)
```bash
npm install -g @angular/cli
ng version
```

### Install TypeScript (for Experiment 01)
```bash
npm install -g typescript
tsc --version
```

---

## 📁 How to Open the Project in VS Code

1. Open VS Code
2. Go to **File → Open Folder**
3. Select the `Full_Stack_Web_Development_Lab_Experiments` folder
4. Each experiment is in its own subfolder

---

## 🚀 Quick Run Guide

| Experiment | Run Command | URL / Output |
|-----------|-------------|--------------|
| 01 | `tsc *.ts && node main` | Terminal output |
| 02 | `ng serve` | http://localhost:4200 |
| 03 | `ng serve` | http://localhost:4200 |
| 04 | `ng serve` | http://localhost:4200 |
| 05 | `ng serve` | http://localhost:4200 |
| 06 | `ng serve` | http://localhost:4200 |
| 07 | `ng serve` | http://localhost:4200 |
| 08 | `node index.js` | http://localhost:3000 |
| 09 | `node index.js` | http://localhost:3000 |
| 10 | `node index.js` | http://localhost:3000 |

---

## 📦 Installing All Dependencies

### Angular Projects (Expt 02–07)
Each Angular experiment is a standalone project. Navigate into the folder and run:
```bash
npm install
ng serve
```

### Express/Node Projects (Expt 08–10)
```bash
cd Experiment-XX/myapp
npm install
node index.js
```

---

## ⚠️ Important Notes
- Experiments 02–07 each contain a full Angular project. Run `npm install` before `ng serve`.
- Experiment 10 requires MongoDB running locally on port 27017.
- Use Postman for testing REST APIs in Experiments 08, 09, and 10.
