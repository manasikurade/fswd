/**
 * counter.service.ts
 * Simple counter service to demonstrate that ONE service
 * instance is shared across multiple components (singleton).
 * Both ComponentA and ComponentB share the same count value.
 */
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CounterService {
  private count = 0;

  increment() { this.count++; }
  decrement() { if (this.count > 0) this.count--; }
  reset()     { this.count = 0; }
  getCount()  { return this.count; }
}
