/**
 * student.service.ts
 * ─────────────────────────────────────────────────────────────
 * Experiment 07 – Services & Dependency Injection in Angular
 *
 * This service acts as a SHARED DATA STORE for student records.
 * Both StudentListComponent and StudentAddComponent inject it.
 * This avoids duplicating data logic in every component.
 *
 * Key decorator: @Injectable({ providedIn: 'root' })
 *   → Makes this service a singleton, available app-wide.
 * ─────────────────────────────────────────────────────────────
 */

import { Injectable } from '@angular/core';

export interface Student {
  id     : number;
  name   : string;
  branch : string;
  marks  : number;
  email  : string;
}

@Injectable({
  providedIn: 'root'    // singleton – one instance for whole app
})
export class StudentService {

  // Private data array – only accessible through service methods
  private students: Student[] = [
    { id: 1, name: 'Alice',  branch: 'CSE',   marks: 92, email: 'alice@tei.ac.in'  },
    { id: 2, name: 'Bob',    branch: 'IT',    marks: 78, email: 'bob@tei.ac.in'    },
    { id: 3, name: 'Carol',  branch: 'MECH',  marks: 85, email: 'carol@tei.ac.in'  },
    { id: 4, name: 'Dave',   branch: 'CIVIL', marks: 70, email: 'dave@tei.ac.in'   },
  ];

  private nextId = 5;

  // ── READ ──────────────────────────────────────────────────
  getAllStudents(): Student[] {
    return this.students;
  }

  getStudentById(id: number): Student | undefined {
    return this.students.find(s => s.id === id);
  }

  getTotalCount(): number {
    return this.students.length;
  }

  getAverageMarks(): number {
    if (this.students.length === 0) return 0;
    const total = this.students.reduce((sum, s) => sum + s.marks, 0);
    return Math.round(total / this.students.length);
  }

  getTopScorer(): Student | undefined {
    return this.students.reduce((top, s) => s.marks > top.marks ? s : top, this.students[0]);
  }

  // ── CREATE ────────────────────────────────────────────────
  addStudent(s: Omit<Student, 'id'>): void {
    this.students.push({ id: this.nextId++, ...s });
  }

  // ── DELETE ────────────────────────────────────────────────
  deleteStudent(id: number): void {
    this.students = this.students.filter(s => s.id !== id);
  }
}
