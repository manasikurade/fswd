/**
 * ============================================================
 * Experiment No.: 07
 * Title        : Demonstrate Services in Angular
 * Purpose      : Reuse logic across multiple components using
 *                Angular Services and Dependency Injection (DI).
 * Technologies : Angular 17+, @Injectable, DI
 * ============================================================
 * HOW TO RUN:
 *   cd Experiment-07/my-first-app && npm install && ng serve
 *   Visit: http://localhost:4200
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StudentService, Student } from './services/student.service';
import { CounterService } from './services/counter.service';

// ── STUDENT LIST COMPONENT ────────────────────────────────────
@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="section">
      <h3>📋 Student List <span class="badge">{{ svc.getTotalCount() }} students</span></h3>
      <table class="tbl">
        <thead><tr><th>#</th><th>Name</th><th>Branch</th><th>Marks</th><th>Email</th><th>Action</th></tr></thead>
        <tbody>
          <tr *ngFor="let s of svc.getAllStudents()">
            <td>{{ s.id }}</td>
            <td>{{ s.name }}</td>
            <td>{{ s.branch }}</td>
            <td [class.high]="s.marks >= 85">{{ s.marks }}</td>
            <td>{{ s.email }}</td>
            <td><button class="del-btn" (click)="svc.deleteStudent(s.id)">🗑️</button></td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .section { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); }
    h3 { color: #0d47a1; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; }
    .badge { background: #1976d2; color: white; padding: 2px 10px; border-radius: 12px; font-size: 0.8rem; }
    .tbl { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
    .tbl th { background: #1976d2; color: white; padding: 10px 12px; text-align: left; }
    .tbl td { padding: 9px 12px; border-bottom: 1px solid #f0f0f0; color: #333; }
    .tbl tr:hover td { background: #e3f2fd; }
    td.high { color: #2e7d32; font-weight: 700; }
    .del-btn { background: #ffcdd2; border: none; border-radius: 6px; padding: 4px 10px; cursor: pointer; color: #c62828; transition: background 0.2s; }
    .del-btn:hover { background: #e53935; color: white; }
  `]
})
export class StudentListComponent {
  constructor(public svc: StudentService) {}
}

// ── STUDENT ADD COMPONENT ─────────────────────────────────────
@Component({
  selector: 'app-student-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="section">
      <h3>➕ Add New Student</h3>
      <div *ngIf="added" class="success">✅ {{ lastAdded }} added successfully!</div>
      <div class="form-row">
        <input [(ngModel)]="form.name"   placeholder="Name"   class="inp" />
        <input [(ngModel)]="form.branch" placeholder="Branch" class="inp" />
        <input [(ngModel)]="form.marks"  placeholder="Marks"  class="inp" type="number" />
        <input [(ngModel)]="form.email"  placeholder="Email"  class="inp" type="email" />
        <button (click)="add()" class="add-btn">Add Student</button>
      </div>
    </div>
  `,
  styles: [`
    .section { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); }
    h3 { color: #0d47a1; margin-bottom: 16px; }
    .form-row { display: flex; gap: 10px; flex-wrap: wrap; }
    .inp { padding: 9px 14px; border: 2px solid #bbdefb; border-radius: 8px; font-size: 0.9rem; outline: none; min-width: 140px; flex: 1; }
    .inp:focus { border-color: #1976d2; }
    .add-btn { padding: 9px 22px; background: #1976d2; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; white-space: nowrap; }
    .add-btn:hover { background: #0d47a1; }
    .success { background: #e8f5e9; color: #2e7d32; padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; border-left: 4px solid #43a047; }
  `]
})
export class StudentAddComponent {
  form = { name: '', branch: '', marks: 0, email: '' };
  added = false;
  lastAdded = '';

  constructor(private svc: StudentService) {}

  add(): void {
    if (this.form.name && this.form.branch && this.form.email) {
      this.svc.addStudent({ ...this.form });
      this.lastAdded = this.form.name;
      this.form = { name: '', branch: '', marks: 0, email: '' };
      this.added = true;
      setTimeout(() => this.added = false, 3000);
    }
  }
}

// ── STATS COMPONENT ───────────────────────────────────────────
@Component({
  selector: 'app-stats',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="stats-row">
      <div class="stat-card blue">
        <span class="stat-num">{{ svc.getTotalCount() }}</span>
        <span class="stat-lbl">Total Students</span>
      </div>
      <div class="stat-card green">
        <span class="stat-num">{{ svc.getAverageMarks() }}</span>
        <span class="stat-lbl">Avg Marks</span>
      </div>
      <div class="stat-card orange">
        <span class="stat-num">{{ svc.getTopScorer()?.marks }}</span>
        <span class="stat-lbl">Top Score ({{ svc.getTopScorer()?.name }})</span>
      </div>
    </div>
  `,
  styles: [`
    .stats-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; }
    .stat-card { background: white; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,0.07); display: flex; flex-direction: column; gap: 4px; }
    .stat-num { font-size: 2.4rem; font-weight: 800; }
    .stat-lbl { font-size: 0.82rem; color: #777; }
    .blue   .stat-num { color: #1976d2; }
    .green  .stat-num { color: #2e7d32; }
    .orange .stat-num { color: #e65100; }
  `]
})
export class StatsComponent {
  constructor(public svc: StudentService) {}
}

// ── COUNTER DEMO COMPONENT ────────────────────────────────────
@Component({
  selector: 'app-counter-demo',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="section">
      <h3>🔢 Shared Counter Service Demo</h3>
      <p class="desc">Both blocks below use the <strong>same CounterService instance</strong>. Changing count in one reflects in the other.</p>
      <div class="counters">
        <div class="counter-box">
          <h4>Component A</h4>
          <div class="count-display">{{ cs.getCount() }}</div>
          <div class="btn-row">
            <button (click)="cs.decrement()" class="c-btn red">−</button>
            <button (click)="cs.reset()"     class="c-btn grey">Reset</button>
            <button (click)="cs.increment()" class="c-btn green">+</button>
          </div>
        </div>
        <div class="counter-box">
          <h4>Component B (same service!)</h4>
          <div class="count-display">{{ cs.getCount() }}</div>
          <div class="btn-row">
            <button (click)="cs.decrement()" class="c-btn red">−</button>
            <button (click)="cs.reset()"     class="c-btn grey">Reset</button>
            <button (click)="cs.increment()" class="c-btn green">+</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .section { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); }
    h3 { color: #0d47a1; margin-bottom: 8px; }
    .desc { color: #777; font-size: 0.88rem; margin-bottom: 20px; }
    .counters { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    @media (max-width: 500px) { .counters { grid-template-columns: 1fr; } }
    .counter-box { border: 2px solid #bbdefb; border-radius: 12px; padding: 20px; text-align: center; }
    h4 { color: #0d47a1; margin-bottom: 12px; font-size: 0.95rem; }
    .count-display { font-size: 3rem; font-weight: 800; color: #1976d2; margin: 12px 0; }
    .btn-row { display: flex; gap: 8px; justify-content: center; }
    .c-btn { padding: 8px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 1.2rem; font-weight: 700; transition: all 0.15s; }
    .c-btn.red   { background: #ffcdd2; color: #c62828; } .c-btn.red:hover   { background: #e53935; color: white; }
    .c-btn.green { background: #c8e6c9; color: #1b5e20; } .c-btn.green:hover { background: #43a047; color: white; }
    .c-btn.grey  { background: #e0e0e0; color: #333; }    .c-btn.grey:hover  { background: #9e9e9e; color: white; }
  `]
})
export class CounterDemoComponent {
  constructor(public cs: CounterService) {}
}

// ── ROOT APP COMPONENT ────────────────────────────────────────
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, StudentListComponent, StudentAddComponent, StatsComponent, CounterDemoComponent],
  template: `
    <div class="page-wrapper">
      <header class="header">
        <h2>Experiment 07 – Services &amp; Dependency Injection in Angular</h2>
        <p>TEI Ichalkaranji | Full Stack Web Dev Lab</p>
      </header>
      <main class="content">
        <div class="section-label">📊 Statistics (computed by StudentService)</div>
        <app-stats></app-stats>

        <div class="section-label">➕ Add Student (uses StudentService)</div>
        <app-student-add></app-student-add>

        <div class="section-label">📋 Student List (same StudentService instance)</div>
        <app-student-list></app-student-list>

        <div class="section-label">🔢 Singleton Proof – Shared CounterService</div>
        <app-counter-demo></app-counter-demo>
      </main>
    </div>
  `,
  styles: [`
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; }
    .page-wrapper { min-height: 100vh; }
    .header { background: linear-gradient(135deg, #0d47a1, #1976d2); color: white; padding: 20px 32px; text-align: center; }
    .header h2 { font-size: 1.3rem; margin-bottom: 4px; }
    .header p  { font-size: 0.85rem; opacity: 0.85; }
    .content { max-width: 1000px; margin: 0 auto; padding: 32px 16px; display: flex; flex-direction: column; gap: 20px; }
    .section-label { font-weight: 700; color: #0d47a1; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 6px 0 2px; border-bottom: 2px solid #1976d2; }
  `]
})
export class AppComponent {}
