# Experiment 07 – Services & Dependency Injection in Angular

## Aim
Demonstrate reusing code across multiple components using Angular Services and Dependency Injection (DI).

## Services Created
| Service | Purpose |
|---------|---------|
| `StudentService` | CRUD operations for student data – shared by list, add, stats components |
| `CounterService` | Shared counter to prove singleton behavior |

## Setup & Run

```bash
cd Experiment-07/my-first-app
npm install
ng serve
# http://localhost:4200
```

## How DI Works
```typescript
// 1. Create service with @Injectable
@Injectable({ providedIn: 'root' })  // singleton
export class StudentService { ... }

// 2. Inject in component constructor
constructor(private studentService: StudentService) {}

// 3. Use the service
this.studentService.getAllStudents();
```

## What's Demonstrated
- **StudentService** is injected into 3 separate components (Stats, Add, List) — all share the same data.
- **CounterService** shows that adding in Component A immediately reflects in Component B.
- `providedIn: 'root'` = app-wide singleton (one instance).

## Viva Questions
1. What is a service in Angular? → A class with `@Injectable` that encapsulates shared logic.
2. What is Dependency Injection? → Angular automatically provides service instances to components.
3. What does `providedIn: 'root'` mean? → Service is a singleton, available anywhere in the app.
4. Can one service be injected into another? → Yes, services can depend on other services.
