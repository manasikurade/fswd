# Experiment 05 – Structural Directives in Angular

## Aim
Demonstrate `*ngIf`, `*ngFor`, and `*ngSwitch` for conditionally rendering HTML elements.

## Setup & Run

```bash
cd Experiment-05/my-first-app
npm install
ng serve
# http://localhost:4200
```

## What's Demonstrated

| Directive | What it does |
|-----------|-------------|
| `*ngIf` | Shows/hides elements based on a boolean condition |
| `*ngIf...else` | Shows alternate `<ng-template>` when condition is false |
| `*ngFor` | Loops through an array to render repeated elements |
| `ngFor` locals | `index`, `first`, `last`, `even`, `odd` |
| `*ngSwitch` | Renders one block from multiple cases based on value |

## Viva Questions
1. How does `*ngIf` differ from `[hidden]`? → `*ngIf` removes element from DOM; `[hidden]` just hides it with CSS.
2. What is `ng-template`? → A placeholder that renders content conditionally (used with `*ngIf else`).
3. What are `ngFor` local variables? → `index`, `first`, `last`, `even`, `odd` available in the loop.
4. What is `[ngSwitch]` vs `*ngSwitchCase`? → `[ngSwitch]` goes on parent; `*ngSwitchCase` on each child.
