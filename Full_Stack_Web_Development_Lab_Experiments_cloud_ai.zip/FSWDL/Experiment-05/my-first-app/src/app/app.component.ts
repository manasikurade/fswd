/**
 * ============================================================
 * Experiment No.: 05
 * Title        : Demonstrate Structural Directives in Angular
 * Purpose      : Use *ngIf, *ngFor, and *ngSwitch to conditionally
 *                render HTML elements in the DOM.
 * Technologies : Angular 17+, TypeScript
 * ============================================================
 * HOW TO RUN:
 *   cd Experiment-05/my-first-app && npm install && ng serve
 *   Visit: http://localhost:4200
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Student {
  id: number;
  name: string;
  branch: string;
  marks: number;
  grade: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // ── *ngIf demo ───────────────────────────────────
  showMessage = false;
  isLoggedIn  = false;

  toggleMessage(): void  { this.showMessage = !this.showMessage; }
  toggleLogin(): void    { this.isLoggedIn  = !this.isLoggedIn;  }

  // ── *ngFor demo ──────────────────────────────────
  students: Student[] = [
    { id: 1, name: 'Alice',   branch: 'CSE',  marks: 92, grade: 'A+' },
    { id: 2, name: 'Bob',     branch: 'IT',   marks: 78, grade: 'B'  },
    { id: 3, name: 'Carol',   branch: 'MECH', marks: 85, grade: 'A'  },
    { id: 4, name: 'Dave',    branch: 'CSE',  marks: 55, grade: 'C'  },
    { id: 5, name: 'Eve',     branch: 'CIVIL',marks: 70, grade: 'B'  },
  ];

  fruits: string[] = ['🍎 Apple', '🍌 Banana', '🥭 Mango', '🍊 Orange', '🍇 Grapes'];
  newFruit = '';

  addFruit(): void {
    if (this.newFruit.trim()) {
      this.fruits.push(this.newFruit.trim());
      this.newFruit = '';
    }
  }
  removeFruit(i: number): void { this.fruits.splice(i, 1); }

  // ── *ngSwitch demo ──────────────────────────────
  selectedColor = 'red';
  selectedDay   = 'Monday';

  days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  getDayType(day: string): string {
    return ['Saturday', 'Sunday'].includes(day) ? 'Weekend 🎉' : 'Weekday 💼';
  }
}
