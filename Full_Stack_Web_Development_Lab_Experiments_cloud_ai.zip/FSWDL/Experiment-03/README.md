# Experiment 03 – Data Binding & Event Binding in Angular

## Aim
Demonstrate the flow of data from component to template (one-way) and from template to component (two-way) using Angular's binding mechanisms.

## Concepts Covered

| Type | Syntax | Direction |
|------|--------|-----------|
| Interpolation | `{{ value }}` | Component → Template |
| Property Binding | `[property]="value"` | Component → Template |
| Event Binding | `(event)="handler()"` | Template → Component |
| Two-Way Binding | `[(ngModel)]="value"` | Both directions |

## Setup & Run

```bash
cd Experiment-03/my-first-app
npm install
ng serve
# Open http://localhost:4200
```

## Expected Output
- **Section 1**: Displays variables using `{{ }}` interpolation.
- **Section 2**: Shows Angular logo via `[src]` property binding; toggle button via `[disabled]`.
- **Section 3**: Click counter updates on `(click)` event; keystroke logger on `(keyup)`.
- **Section 4**: Live name display and character counter via `[(ngModel)]` two-way binding.

## Key Notes
- `FormsModule` must be imported for `[(ngModel)]` to work.
- Event binding uses `$event` to pass the DOM event object to the handler.
- Two-way binding = Property binding + Event binding combined: `[(ngModel)]` = `[ngModel] + (ngModelChange)`.

## Viva Questions
1. What is interpolation? → Embedding component expressions in HTML using `{{ }}`.
2. What module is needed for ngModel? → `FormsModule` from `@angular/forms`.
3. Difference between `[value]` and `[(value)]`? → `[]` is one-way; `[()]` is two-way.
