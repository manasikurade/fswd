/**
 * ============================================================
 * Experiment No.: 03
 * Title        : Demonstrate Data Binding and Event Binding in Angular
 * Purpose      : Show interpolation, property binding, event binding,
 *                and two-way data binding using [(ngModel)].
 * Technologies : Angular 17+, TypeScript, HTML, CSS
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. Open folder: Experiment-03/my-first-app
 *   2. Run: npm install
 *   3. Run: ng serve
 *   4. Visit: http://localhost:4200
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],   // FormsModule needed for [(ngModel)]
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // ── 1. Interpolation ──────────────────────────────────────
  // These variables are displayed in the template using {{ }}
  title = 'Data Binding Demo – Angular';
  userName = 'Alice';
  rollNumber = 101;
  currentDate = new Date().toLocaleDateString();

  // ── 2. Property Binding ───────────────────────────────────
  // imageUrl is bound to [src] of <img> element
  imageUrl = 'https://angular.io/assets/images/logos/angular/angular.png';
  imageAlt = 'Angular Logo';
  isDisabled = false;      // bound to [disabled] of a button
  btnColor  = 'primary';

  // ── 3. Event Binding ──────────────────────────────────────
  clickCount = 0;
  lastClickMessage = 'No button clicked yet.';

  onButtonClick(): void {
    this.clickCount++;
    this.lastClickMessage = `Button was clicked ${this.clickCount} time(s)!`;
    console.log('Hello World – Button Clicked!');
  }

  onMouseOver(): void {
    console.log('Mouse over the card!');
  }

  onKeyUp(event: KeyboardEvent): void {
    const key = (event.target as HTMLInputElement).value;
    console.log('Key typed:', key);
  }

  toggleDisable(): void {
    this.isDisabled = !this.isDisabled;
  }

  // ── 4. Two-Way Data Binding ───────────────────────────────
  // twoWayName is kept in sync between input field and paragraph
  twoWayName = 'John Doe';

  // Extra two-way demo – live character count
  userMessage = '';
  get charCount(): number {
    return this.userMessage.length;
  }
}
