# Experiment 04 – Form Development Using Angular

## Aim
To design and implement forms in Angular for capturing and validating user input using both Template-driven and Reactive approaches.

## Concepts Covered
- **Template-Driven Forms** – Using `ngModel`, `#ref="ngModel"`, `required`, `email`, `pattern`
- **Reactive Forms** – Using `FormBuilder`, `FormGroup`, `FormControl`, `Validators`
- Built-in validators: `required`, `minlength`, `email`, `pattern`, `requiredTrue`
- Form states: `valid`, `invalid`, `dirty`, `touched`, `pristine`

## Setup & Run

```bash
cd Experiment-04/my-first-app
npm install
ng serve
# Open http://localhost:4200
```

## Expected Output
Two tabs:
1. **Template-Driven Form** – Student registration with Name, Email, Phone, Course fields + validation messages
2. **Reactive Form** – Full registration with Name, Email, Password, Phone, Gender, Terms checkbox

## Key Notes
- Import `FormsModule` for template-driven; `ReactiveFormsModule` for reactive forms.
- `f['fieldName']` is a getter shortcut to access form controls.
- `[class.invalid]` applies CSS class conditionally based on control validity.

## Viva Questions
1. What is `FormBuilder`? → A helper service to reduce boilerplate when creating reactive forms.
2. What is `Validators.required`? → A built-in validator that ensures a field is not empty.
3. How to show validation only on submit? → Track `submitted` boolean and use `(submitted || control.dirty)`.
