/**
 * ============================================================
 * Experiment No.: 04
 * Title        : Form Development Using Angular
 * Purpose      : Design and implement both Template-driven and
 *                Reactive forms with validation in Angular.
 * Technologies : Angular 17+, FormsModule, ReactiveFormsModule
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. cd Experiment-04/my-first-app
 *   2. npm install
 *   3. ng serve
 *   4. http://localhost:4200
 * ============================================================
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  activeTab: 'template' | 'reactive' = 'template';

  // ── A. TEMPLATE-DRIVEN FORM ────────────────────────────────
  // Model object used with ngModel
  templateModel = {
    name: '',
    email: '',
    phone: '',
    course: ''
  };
  templateSubmitted = false;
  templateSuccess = false;

  onTemplateSubmit(form: any): void {
    this.templateSubmitted = true;
    if (form.valid) {
      this.templateSuccess = true;
      console.log('Template Form Data:', this.templateModel);
    }
  }

  resetTemplateForm(form: any): void {
    form.resetForm();
    this.templateModel = { name: '', email: '', phone: '', course: '' };
    this.templateSubmitted = false;
    this.templateSuccess = false;
  }

  // ── B. REACTIVE FORM ──────────────────────────────────────
  reactiveForm: FormGroup;
  reactiveSubmitted = false;
  reactiveSuccess = false;

  constructor(private fb: FormBuilder) {
    this.reactiveForm = this.fb.group({
      fullName : ['', [Validators.required, Validators.minLength(3)]],
      email    : ['', [Validators.required, Validators.email]],
      password : ['', [Validators.required, Validators.minLength(6)]],
      phone    : ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      gender   : ['', Validators.required],
      agree    : [false, Validators.requiredTrue]
    });
  }

  // Getter helpers for easy template access
  get f() { return this.reactiveForm.controls; }

  onReactiveSubmit(): void {
    this.reactiveSubmitted = true;
    if (this.reactiveForm.valid) {
      this.reactiveSuccess = true;
      console.log('Reactive Form Data:', this.reactiveForm.value);
    }
  }

  resetReactiveForm(): void {
    this.reactiveForm.reset();
    this.reactiveSubmitted = false;
    this.reactiveSuccess = false;
  }
}
