/**
 * ============================================================
 * Experiment No.: 01
 * Title        : Demonstrate various programming concepts using TypeScript
 * Purpose      : Learn the basic building blocks of TypeScript –
 *                types, functions, interfaces, classes, and modules.
 * Technologies : TypeScript, Node.js, npm
 * ============================================================
 * HOW TO RUN IN VS CODE:
 *   1. Open VS Code and open this folder (Experiment-01).
 *   2. Open the integrated terminal (Ctrl + `).
 *   3. Install TypeScript globally (if not already installed):
 *         npm install -g typescript
 *   4. Compile ALL .ts files:
 *         tsc --outDir dist main.ts mathFunctions.ts
 *      OR compile only main.ts (it imports mathFunctions automatically):
 *         tsc main.ts
 *   5. Run the compiled JavaScript:
 *         node main.js
 * ============================================================
 * EXTRA SETUP:
 *   - Node.js must be installed (https://nodejs.org)
 *   - TypeScript must be installed globally via npm
 * ============================================================
 */

// ─────────────────────────────────────────────
// 1. TYPES – Explicit and Implicit declarations
// ─────────────────────────────────────────────
console.log("====== 1. TYPES ======");

// Explicit type assignment
let firstName: string = "Alice";
let age: number = 22;
let isStudent: boolean = true;

// Implicit type (TypeScript infers the type)
let lastName = "Sharma";   // inferred as string
let marks = 95.5;          // inferred as number

console.log(`Name   : ${firstName} ${lastName}`);
console.log(`Age    : ${age}`);
console.log(`Student: ${isStudent}`);
console.log(`Marks  : ${marks}`);

// Special types
let anything: any = "I can be anything";
anything = 42;             // no error because it is 'any'

let notDefined: undefined = undefined;
let empty: null = null;

console.log(`Any    : ${anything}`);
console.log(`Undef  : ${notDefined}`);
console.log(`Null   : ${empty}`);

// ─────────────────────────────────────────────
// 2. FUNCTIONS – Typed parameters & return types
// ─────────────────────────────────────────────
console.log("\n====== 2. FUNCTIONS ======");

// Function with return type
function greet(name: string, roll: number): string {
  return `Hello, ${name}! Your roll number is ${roll}.`;
}

// Function with void return type (no return value)
function printLine(message: string): void {
  console.log(`>> ${message}`);
}

// Arrow function
const multiply = (a: number, b: number): number => a * b;

// Optional parameter (use ?)
function introduce(name: string, city?: string): string {
  return city
    ? `I am ${name} from ${city}.`
    : `I am ${name}.`;
}

console.log(greet("Bob", 101));
printLine("This is a void function.");
console.log(`3 x 4 = ${multiply(3, 4)}`);
console.log(introduce("Carol"));
console.log(introduce("Dave", "Pune"));

// ─────────────────────────────────────────────
// 3. INTERFACE – Defining object shape / contract
// ─────────────────────────────────────────────
console.log("\n====== 3. INTERFACE ======");

// Basic interface
interface Student {
  name: string;
  rollNo: number;
  branch: string;
  display(): void;   // method declaration
}

// Implementing the interface in an object literal
const student1: Student = {
  name: "Eve",
  rollNo: 201,
  branch: "CSE",
  display() {
    console.log(`Student: ${this.name} | Roll: ${this.rollNo} | Branch: ${this.branch}`);
  },
};

student1.display();

// Interface for a function type
interface MathOperation {
  (x: number, y: number): number;
}

const addNumbers: MathOperation = (x, y) => x + y;
console.log(`Add 10 + 20 = ${addNumbers(10, 20)}`);

// Interface for an array
interface StringArray {
  [index: number]: string;
}
const fruits: StringArray = ["Apple", "Banana", "Mango"];
console.log(`Fruits[1] = ${fruits[1]}`);

// ─────────────────────────────────────────────
// 4. INTERFACE INHERITANCE
// ─────────────────────────────────────────────
console.log("\n====== 4. INTERFACE INHERITANCE ======");

interface Person {
  name: string;
  age: number;
}

interface Employee extends Person {
  empId: string;
  department: string;
}

// Multiple interface inheritance
interface Manager extends Person, Employee {
  teamSize: number;
}

const emp: Employee = {
  name: "Frank",
  age: 30,
  empId: "E001",
  department: "Engineering",
};

const mgr: Manager = {
  name: "Grace",
  age: 40,
  empId: "M001",
  department: "Management",
  teamSize: 10,
};

console.log(`Employee : ${emp.name}, Dept: ${emp.department}`);
console.log(`Manager  : ${mgr.name}, Team Size: ${mgr.teamSize}`);

// ─────────────────────────────────────────────
// 5. CLASS – Blueprint for objects
// ─────────────────────────────────────────────
console.log("\n====== 5. CLASS ======");

class Animal {
  // Properties
  name: string;
  sound: string;

  // Constructor
  constructor(name: string, sound: string) {
    this.name = name;
    this.sound = sound;
  }

  // Method
  speak(): void {
    console.log(`${this.name} says: ${this.sound}`);
  }
}

// Class inheritance
class Dog extends Animal {
  breed: string;

  constructor(name: string, breed: string) {
    super(name, "Woof");   // calls Animal's constructor
    this.breed = breed;
  }

  info(): void {
    console.log(`Dog: ${this.name} | Breed: ${this.breed}`);
  }
}

// Access modifiers example
class BankAccount {
  private balance: number;           // only accessible within class
  protected accountNumber: string;   // accessible in subclasses
  public owner: string;              // accessible everywhere

  constructor(owner: string, initialBalance: number) {
    this.owner = owner;
    this.balance = initialBalance;
    this.accountNumber = "ACC" + Math.floor(Math.random() * 10000);
  }

  deposit(amount: number): void {
    this.balance += amount;
    console.log(`Deposited ₹${amount}. New balance: ₹${this.balance}`);
  }

  getBalance(): number {
    return this.balance;
  }
}

const cat = new Animal("Cat", "Meow");
cat.speak();

const dog = new Dog("Rex", "German Shepherd");
dog.speak();
dog.info();

const account = new BankAccount("Henry", 5000);
account.deposit(2000);
console.log(`Balance for ${account.owner}: ₹${account.getBalance()}`);

// ─────────────────────────────────────────────
// 6. MODULES – Using exported functions
//    (mathFunctions.ts is imported below)
// ─────────────────────────────────────────────
console.log("\n====== 6. MODULES ======");

// Import from mathFunctions.ts
import { add, subtract, multiply as mul, divide } from "./mathFunctions";

console.log(`add(5, 3)       = ${add(5, 3)}`);
console.log(`subtract(10, 4) = ${subtract(10, 4)}`);
console.log(`multiply(6, 7)  = ${mul(6, 7)}`);
console.log(`divide(20, 4)   = ${divide(20, 4)}`);

console.log("\n✅ All TypeScript concepts demonstrated successfully!");
