# Experiment 01 – TypeScript Programming Concepts

## Aim
To demonstrate the basic building blocks of TypeScript including types, functions, interfaces, interface inheritance, classes, and modules.

## Technologies Used
- TypeScript
- Node.js
- npm

## Folder Structure
```
Experiment-01/
├── main.ts           ← Main TypeScript file (all concepts demonstrated)
├── mathFunctions.ts  ← Separate module with exported math functions
├── tsconfig.json     ← TypeScript compiler configuration
└── README.md
```

## Setup Steps

### Step 1 – Install Node.js
Download and install from https://nodejs.org

### Step 2 – Install TypeScript
```bash
npm install -g typescript
tsc --version
```

## How to Run in VS Code

1. Open VS Code → File → Open Folder → select `Experiment-01`
2. Open terminal (Ctrl + `)
3. Compile using tsconfig:
   ```bash
   tsc
   ```
4. Run the compiled output:
   ```bash
   node dist/main.js
   ```

**OR compile and run in one step (without tsconfig):**
```bash
tsc main.ts mathFunctions.ts --module commonjs --target ES6
node main.js
```

## Expected Output
```
====== 1. TYPES ======
Name   : Alice Sharma
Age    : 22
Student: true
Marks  : 95.5
Any    : 42
...
====== 2. FUNCTIONS ======
Hello, Bob! Your roll number is 101.
...
====== 3. INTERFACE ======
Student: Eve | Roll: 201 | Branch: CSE
...
====== 4. INTERFACE INHERITANCE ======
Employee : Frank, Dept: Engineering
...
====== 5. CLASS ======
Cat says: Meow
Rex says: Woof
...
====== 6. MODULES ======
add(5, 3)       = 8
subtract(10, 4) = 6
...
✅ All TypeScript concepts demonstrated successfully!
```

## Key Concepts Covered
| Concept | Description |
|---------|-------------|
| Types | `string`, `number`, `boolean`, `any`, `null`, `undefined` |
| Functions | Typed parameters, return types, optional params, arrow functions |
| Interfaces | Object contracts, function types, array types |
| Inheritance | `extends` keyword, single and multiple interface inheritance |
| Classes | Constructor, properties, methods, access modifiers, inheritance |
| Modules | `export` and `import` across files |

## Viva Questions & Notes
1. **What is TypeScript?** A statically typed superset of JavaScript.
2. **What is transpilation?** Converting TypeScript to JavaScript using `tsc`.
3. **Difference between `any` and `unknown`?** `any` disables type checking; `unknown` is safer.
4. **What is `duck typing`?** TypeScript checks structural compatibility, not class identity.
5. **Access modifiers:** `public` (default), `private`, `protected`.
