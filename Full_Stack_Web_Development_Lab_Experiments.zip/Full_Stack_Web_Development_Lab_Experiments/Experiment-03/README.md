# Experiment-03 - Demonstrate data binding and event binding in Angular

## Aim / Objective
To demonstrate flow of data from component to template and from template to component.

## Technologies Used
- Angular
- TypeScript
- HTML
- CSS
- FormsModule

## How to Run in VS Code
```bash
npm install
npm start
```

## What This Experiment Demonstrates
- Interpolation
- Property binding
- Event binding
- Two-way binding with `ngModel`

## Expected Output
A browser page that shows:
- welcome message using interpolation
- image using property binding
- button click count using event binding
- input field updating text in real time using two-way binding

## Extra Notes
This experiment is ideal for viva questions related to Angular communication between component and template.
