/*
Experiment Name: Demonstrate data binding and event binding in Angular
Purpose:
- To demonstrate interpolation, property binding, event binding, and two-way data binding.

Technologies Used:
- Angular
- TypeScript
- HTML
- CSS
- FormsModule

How to Run in VS Code:
1. Open Experiment-03 in VS Code.
2. Run: npm install
3. Run: npm start
4. Visit http://localhost:4200

Extra Setup Required:
- Angular CLI and Node.js must be installed.
*/

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Angular Binding Demo';
  userName = 'John Doe';
  imageUrl = 'https://picsum.photos/320/180';
  clickCount = 0;
  message = 'Click the button to trigger event binding.';
  skills = ['Angular', 'TypeScript', 'HTML', 'CSS'];

  onButtonClick(): void {
    this.clickCount++;
    this.message = `Button clicked ${this.clickCount} time(s).`;
  }

  resetName(): void {
    this.userName = 'John Doe';
  }
}
