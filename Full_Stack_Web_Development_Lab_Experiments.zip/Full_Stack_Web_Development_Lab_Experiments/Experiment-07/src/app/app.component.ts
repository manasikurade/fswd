/*
Experiment Name: Demonstrate services in Angular
Purpose:
- To demonstrate reuse of data and logic across different components using a service.

Technologies Used:
- Angular
- TypeScript
- HTML
- CSS
- Dependency Injection

How to Run in VS Code:
1. Open Experiment-07 in VS Code.
2. Run: npm install
3. Run: npm start
4. Visit http://localhost:4200

Extra Setup Required:
- None.
*/

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentService } from './student.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  providers: [StudentService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  constructor(public studentService: StudentService) {}

  addDemoStudent(): void {
    this.studentService.addStudent('New Student');
  }
}
