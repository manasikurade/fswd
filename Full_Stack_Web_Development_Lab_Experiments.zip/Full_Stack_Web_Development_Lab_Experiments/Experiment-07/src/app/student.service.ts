/*
This service demonstrates shared logic and data in Angular.
*/
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private students: string[] = ['Asha', 'Bhavesh', 'Charan'];

  getStudents(): string[] {
    return this.students;
  }

  addStudent(name: string): void {
    this.students = [...this.students, `${name} ${this.students.length + 1}`];
  }

  getStudentCount(): number {
    return this.students.length;
  }

  getMessage(): string {
    return 'Student data is coming from a reusable Angular service.';
  }
}
