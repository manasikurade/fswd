# Experiment-07 - Demonstrate services in Angular

## Aim / Objective
To demonstrate reusing code in different components using Angular services.

## Technologies Used
- Angular
- TypeScript
- Dependency Injection
- Service class

## How to Run
```bash
npm install
npm start
```

## Description
This experiment uses a service to:
- hold a shared student list
- provide a common message
- expose reusable methods to the component

## Expected Output
A page showing a student list and count. Clicking the button updates data through the injected service.

## Viva / Important Notes
1. Services improve reusability.
2. Angular DI automatically injects services.
3. Business logic should usually be moved to services instead of writing everything inside components.
