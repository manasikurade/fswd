# Experiment-02 - Create a simple web app using Angular

## Aim / Objective
To explain different basic building blocks of an Angular application.

## Required Software / Technologies
- VS Code
- Node.js
- npm
- Angular CLI
- Angular

## Folder Structure
```text
Experiment-02/
├── angular.json
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── README.md
└── src/
    ├── index.html
    ├── main.ts
    ├── styles.css
    └── app/
        ├── app.component.ts
        ├── app.component.html
        └── app.config.ts
```

## How to Run in VS Code
```bash
npm install
npm start
```

Open: `http://localhost:4200`

## Description
This experiment creates a simple Angular student portal page and demonstrates component creation, interpolation, and list rendering using Angular.

## Expected Output
A page with:
- application title
- subtitle
- date
- Angular feature cards

## Extra Notes
This is a clean academic implementation matching the experiment title from the lab manual.
