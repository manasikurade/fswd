/*
Experiment Name: Create a simple web app using Angular
Purpose:
- To explain different basic building blocks of an Angular application by creating
  a simple student-friendly web app.

Technologies Used:
- Angular
- TypeScript
- HTML
- CSS
- Node.js
- npm

How to Run in VS Code:
1. Open Experiment-02 in VS Code.
2. Open the terminal.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:4200 in your browser.

Extra Setup Required:
- Angular CLI should be available. If needed run:
  npm install -g @angular/cli
*/

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface FeatureCard {
  title: string;
  description: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  appTitle = 'My First Angular App';
  subtitle = 'Simple Student Portal';
  today = new Date();

  features: FeatureCard[] = [
    { title: 'Components', description: 'Reusable UI building blocks in Angular.' },
    { title: 'Templates', description: 'HTML-based views that display dynamic data.' },
    { title: 'Data Binding', description: 'Easy synchronization between logic and UI.' },
    { title: 'Routing', description: 'Move between different pages in a single-page app.' }
  ];
}
