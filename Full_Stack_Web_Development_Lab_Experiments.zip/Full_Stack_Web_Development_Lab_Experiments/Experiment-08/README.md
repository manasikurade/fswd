# Experiment-08 - Handling Routes in Express.js

## Aim / Objective
To demonstrate routing in Express.js according to request method and URL.

## Required Software / Technologies
- VS Code
- Node.js
- npm
- Express.js
- Postman (recommended)

## Folder Structure
```text
Experiment-08/
├── package.json
├── index.js
└── README.md
```

## How to Run in VS Code
```bash
npm install
npm start
```

## Test URLs
- `GET /`
- `POST /`
- `PUT /user`
- `DELETE /user`
- `GET /users/:userId/books/:bookId`
- `GET /flights/:from-:to`
- `GET /plantae/:genus.:species`
- `GET /user/:userId(\d+)`

## Sample Input / Output
Use Postman to send JSON:
```json
{
  "name": "Demo User"
}
```

Response:
```json
{
  "message": "Got a POST request on the homepage.",
  "receivedBody": {
    "name": "Demo User"
  }
}
```

## Extra Notes
This experiment covers static routes, method-based routes, route parameters, and regex-style route matching.
