/*
Experiment Name: Handling Routes in Express.js
Purpose:
- To demonstrate routing in Express based on HTTP method and URL.

Technologies Used:
- Node.js
- Express.js
- JavaScript
- Postman / browser

How to Run in VS Code:
1. Open Experiment-08 in VS Code.
2. Open terminal.
3. Run: npm install
4. Run: npm start
5. Open browser or Postman.
6. Test:
   - GET    http://localhost:3000/
   - POST   http://localhost:3000/
   - PUT    http://localhost:3000/user
   - DELETE http://localhost:3000/user
   - GET    http://localhost:3000/users/34/books/8989
   - GET    http://localhost:3000/flights/LAX-SFO
   - GET    http://localhost:3000/plantae/Prunus.persica

Extra Setup Required:
- No database required.
*/

const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Hello World! This is a GET request on the homepage.');
});

app.post('/', (req, res) => {
  res.json({
    message: 'Got a POST request on the homepage.',
    receivedBody: req.body
  });
});

app.put('/user', (req, res) => {
  res.json({
    message: 'Got a PUT request at /user',
    body: req.body
  });
});

app.delete('/user', (req, res) => {
  res.send('Got a DELETE request at /user');
});

app.get('/users/:userId/books/:bookId', (req, res) => {
  res.json({
    message: 'Route parameters example',
    params: req.params
  });
});

app.get('/flights/:from-:to', (req, res) => {
  res.json({
    message: 'Hyphen-separated route parameter example',
    params: req.params
  });
});

app.get('/plantae/:genus.:species', (req, res) => {
  res.json({
    message: 'Dot-separated route parameter example',
    params: req.params
  });
});

app.get('/user/:userId(\\d+)', (req, res) => {
  res.json({
    message: 'Regex route parameter example',
    params: req.params
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Experiment-08 server is running on http://localhost:${PORT}`);
});
