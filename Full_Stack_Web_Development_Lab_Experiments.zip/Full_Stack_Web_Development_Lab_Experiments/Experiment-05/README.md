# Experiment-05 - Demonstrate structural directives in Angular

## Aim / Objective
To demonstrate `ngIf`, `ngFor`, and `ngSwitch` for conditionally rendering HTML elements.

## Required Software / Technologies
- Angular
- TypeScript
- Node.js
- npm
- VS Code

## How to Run
```bash
npm install
npm start
```

## What This Experiment Covers
- `*ngIf` for conditional display
- `*ngFor` for list rendering
- `ngSwitch` for switch-case style rendering

## Expected Output
A page with:
- toggle button for `ngIf`
- student list rendered using `ngFor`
- selected color message rendered using `ngSwitch`

## Viva / Important Notes
Structural directives change DOM structure, unlike attribute directives which only change appearance or behavior.
