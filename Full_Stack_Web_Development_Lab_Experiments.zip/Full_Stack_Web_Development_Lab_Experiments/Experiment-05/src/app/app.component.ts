/*
Experiment Name: Demonstrate structural directives in Angular
Purpose:
- To demonstrate *ngIf, *ngFor, and [ngSwitch] for conditional and repeated rendering.

Technologies Used:
- Angular
- TypeScript
- HTML
- CSS

How to Run in VS Code:
1. Open Experiment-05 in VS Code.
2. Run: npm install
3. Run: npm start
4. Open http://localhost:4200

Extra Setup Required:
- No extra setup beyond Angular project dependencies.
*/

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  showNotice = true;
  students = ['Aditi', 'Rahul', 'Sneha', 'Kiran'];
  color = 'blue';

  toggleNotice(): void {
    this.showNotice = !this.showNotice;
  }

  setColor(selectedColor: string): void {
    this.color = selectedColor;
  }
}
