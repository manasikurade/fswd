/*
Experiment Name: Demonstrate CRUD operations on MongoDB
Purpose:
- To demonstrate create, read, update, and delete operations on MongoDB using
  Express.js and Mongoose.

Technologies Used:
- Node.js
- Express.js
- MongoDB
- Mongoose
- dotenv
- Postman / browser

How to Run in VS Code:
1. Install MongoDB locally and ensure the MongoDB service is running.
2. Open Experiment-10 in VS Code.
3. Copy .env.example to .env
4. Run: npm install
5. Run: npm start
6. Test routes using Postman:
   - GET    http://localhost:3000/
   - POST   http://localhost:3000/api/items
   - GET    http://localhost:3000/api/items
   - GET    http://localhost:3000/api/items/:id
   - PUT    http://localhost:3000/api/items/:id
   - DELETE http://localhost:3000/api/items/:id

Extra Setup Required:
- MongoDB must be installed and running.
- Use the default URI from .env for local MongoDB.
*/

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const Item = require('./src/models/item');

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/fswd_lab';

app.use(express.json());

mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connected to MongoDB successfully'))
  .catch((error) => {
    console.error('MongoDB connection error:', error.message);
    process.exit(1);
  });

app.get('/', (req, res) => {
  res.send('MongoDB CRUD API is running.');
});

app.post('/api/items', async (req, res) => {
  try {
    const item = await Item.create(req.body);
    res.status(201).json(item);
  } catch (error) {
    res.status(400).json({ message: 'Unable to create item', error: error.message });
  }
});

app.get('/api/items', async (req, res) => {
  try {
    const items = await Item.find().sort({ createdAt: -1 });
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: 'Unable to fetch items', error: error.message });
  }
});

app.get('/api/items/:id', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    res.json(item);
  } catch (error) {
    res.status(400).json({ message: 'Invalid item id', error: error.message });
  }
});

app.put('/api/items/:id', async (req, res) => {
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    res.json(item);
  } catch (error) {
    res.status(400).json({ message: 'Unable to update item', error: error.message });
  }
});

app.delete('/api/items/:id', async (req, res) => {
  try {
    const item = await Item.findByIdAndDelete(req.params.id);

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    res.json({ message: 'Item deleted successfully', deletedItem: item });
  } catch (error) {
    res.status(400).json({ message: 'Unable to delete item', error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Experiment-10 server is running on http://localhost:${PORT}`);
});
