# Experiment-10 - Demonstrate CRUD operations on MongoDB

## Aim / Objective
To demonstrate CRUD operations on MongoDB using Express.js.

## Required Software / Technologies
- VS Code
- Node.js
- npm
- MongoDB
- Express.js
- Mongoose
- Postman

## Folder Structure
```text
Experiment-10/
├── .env.example
├── package.json
├── server.js
├── sample-data.json
├── README.md
└── src/
    └── models/
        └── item.js
```

## How to Run in VS Code
```bash
cp .env.example .env
npm install
npm start
```

## Database Setup
Default MongoDB URL:
```text
mongodb://127.0.0.1:27017/fswd_lab
```

## API Routes
- `POST /api/items`
- `GET /api/items`
- `GET /api/items/:id`
- `PUT /api/items/:id`
- `DELETE /api/items/:id`

## Sample POST Body
```json
{
  "name": "Laptop",
  "quantity": 5,
  "category": "Electronics"
}
```

## Expected Output
JSON responses showing item creation, fetch, update, and deletion.

## Extra Notes
- The PDF title clearly indicates CRUD on MongoDB.
- One objective line in the manual appears inconsistent; this implementation follows the title and theory and is treated as the intended standard experiment.
