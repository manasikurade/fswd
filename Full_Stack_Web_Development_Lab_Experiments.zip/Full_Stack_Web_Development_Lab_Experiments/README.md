# Full Stack Web Development Lab Experiments

This submission-ready folder contains implementations for all 10 experiments listed in the uploaded Full Stack Web Development Lab manual.

## Experiments Included

1. **Experiment-01** - Demonstrate various programming concepts using TypeScript
2. **Experiment-02** - Create a simple web app using Angular
3. **Experiment-03** - Demonstrate data binding and event binding in Angular
4. **Experiment-04** - Demonstration of form development using Angular
5. **Experiment-05** - Demonstrate structural directives in Angular
6. **Experiment-06** - Demonstrate page routing in Angular
7. **Experiment-07** - Demonstrate services in Angular
8. **Experiment-08** - Handling routes in Express.js
9. **Experiment-09** - Demonstrate middlewares in Express.js
10. **Experiment-10** - Demonstrate CRUD operations on MongoDB using Express.js

## Common Software Required

- **VS Code**
- **Node.js** (LTS recommended)
- **npm**
- **Angular CLI** for Angular experiments  
  Install once:
  ```bash
  npm install -g @angular/cli
  ```
- **MongoDB Community Server** for Experiment-10  
  Download and install locally, or use MongoDB Atlas if allowed by your lab.

## How to Open in VS Code

1. Extract this ZIP folder.
2. Open VS Code.
3. Select **File -> Open Folder**.
4. Choose the extracted folder.
5. Open the individual experiment folder you want to run.

## How to Run Angular Experiments (02 to 07)

```bash
cd Experiment-02
npm install
npm start
```

Then open `http://localhost:4200`.

Repeat the same for `Experiment-03` to `Experiment-07`.

## How to Run Node / Express Experiments (08 to 10)

```bash
cd Experiment-08
npm install
npm start
```

Then open `http://localhost:3000` or use Postman / browser as described in each experiment README.

## Folder Structure

```text
Full_Stack_Web_Development_Lab_Experiments/
├── README.md
├── Experiment-01/
├── Experiment-02/
├── Experiment-03/
├── Experiment-04/
├── Experiment-05/
├── Experiment-06/
├── Experiment-07/
├── Experiment-08/
├── Experiment-09/
└── Experiment-10/
```

## Important Notes

- The lab PDFs mostly describe objectives and theory, not complete source code. The implementations in this folder are **standard academic working implementations** created to match the stated experiment titles and steps.
- For **Experiment-10**, the uploaded PDF title is CRUD on MongoDB, but one objective line appears to incorrectly mention middleware. This project follows the **experiment title and body content** and implements CRUD with MongoDB.
- Angular experiments are built as clean **standalone Angular applications** for simplicity and modern compatibility.
- `node_modules` folders are **not included**. Run `npm install` in each project before execution.
- Every experiment contains:
  - objective / aim
  - software / technologies used
  - complete code
  - VS Code run steps
  - extra notes
  - sample behavior / output description

## Suggested ZIP Name

`Full_Stack_Web_Development_Lab_Experiments.zip`
