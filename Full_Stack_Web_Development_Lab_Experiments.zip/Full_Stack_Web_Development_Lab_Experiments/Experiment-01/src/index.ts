/*
Experiment Name: Demonstrate various programming concepts using TypeScript
Purpose:
- Demonstrate TypeScript building blocks such as types, functions, interfaces,
  interface inheritance, classes, objects, arrays, and modules.

Technologies Used:
- TypeScript
- Node.js
- npm

How to Run in VS Code:
1. Open this Experiment-01 folder in VS Code.
2. Open Terminal in VS Code.
3. Run: npm install
4. Run: npm run build
5. Run: npm start
6. Observe the output in the terminal.

Extra Setup Required:
- Node.js must be installed.
- TypeScript compiler is installed locally using npm.

Expected Result:
- The program prints outputs that prove TypeScript concepts are working correctly.
*/

import { add, subtract, multiply } from "./mathFunctions";

type EmployeeRole = "Developer" | "Tester" | "Manager";

let explicitName: string = "Aarav";
let implicitAge = 21;
let isActive: boolean = true;
let anyValue: any = "Can store any type";
let nothingHere: undefined = undefined;
let emptyValue: null = null;

function greetUser(name: string): string {
  return `Hello, ${name}! Welcome to TypeScript.`;
}

function calculateAverage(a: number, b: number, c: number): number {
  return (a + b + c) / 3;
}

interface Person {
  id: number;
  name: string;
  role: EmployeeRole;
  displayInfo(): string;
}

interface ContactInfo {
  email: string;
  phone: string;
}

interface Employee extends Person, ContactInfo {
  department: string;
}

class StaffMember implements Employee {
  constructor(
    public id: number,
    public name: string,
    public role: EmployeeRole,
    public email: string,
    public phone: string,
    public department: string
  ) {}

  displayInfo(): string {
    return `ID: ${this.id}, Name: ${this.name}, Role: ${this.role}, Department: ${this.department}`;
  }

  workSummary(hoursWorked: number): string {
    return `${this.name} worked ${hoursWorked} hours in the ${this.department} department.`;
  }
}

const numbers: number[] = [10, 20, 30, 40];
const employees: Employee[] = [
  new StaffMember(1, "Riya", "Developer", "riya@example.com", "9876543210", "Web"),
  new StaffMember(2, "Vikram", "Tester", "vikram@example.com", "9876501234", "QA")
];

console.log("=== TypeScript Basic Building Blocks Demo ===");
console.log(greetUser(explicitName));
console.log(`Implicit age: ${implicitAge}`);
console.log(`Boolean value: ${isActive}`);
console.log(`Any value: ${anyValue}`);
console.log(`Undefined value: ${nothingHere}`);
console.log(`Null value: ${emptyValue}`);
console.log(`Average of 80, 85, 90 = ${calculateAverage(80, 85, 90)}`);

console.log("\n=== Array Demo ===");
console.log("Numbers:", numbers.join(", "));
console.log("Sum using module function:", add(numbers[0], numbers[1]));
console.log("Difference using module function:", subtract(numbers[3], numbers[1]));
console.log("Multiplication using module function:", multiply(3, 7));

console.log("\n=== Interface + Class Demo ===");
employees.forEach((employee) => {
  console.log(employee.displayInfo());
});

const staff = new StaffMember(
  3,
  "Neha",
  "Manager",
  "neha@example.com",
  "9988776655",
  "Administration"
);

console.log(staff.workSummary(8));

console.log("\n=== Object Demo ===");
const project = {
  title: "Full Stack Lab Submission",
  guide: "Faculty Coordinator",
  completed: true
};
console.log(project);

console.log("\nProgram executed successfully.");
