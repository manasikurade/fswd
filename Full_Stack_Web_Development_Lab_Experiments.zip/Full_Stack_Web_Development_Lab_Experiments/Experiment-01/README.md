# Experiment-01 - Demonstrate various programming concepts using TypeScript

## Aim / Objective
To develop the basic building blocks of TypeScript such as types, functions, interfaces, interface inheritance, classes, objects, arrays, and modules.

## Required Software / Technologies
- VS Code
- Node.js
- npm
- TypeScript

## Folder Structure
```text
Experiment-01/
├── package.json
├── tsconfig.json
├── README.md
└── src/
    ├── index.ts
    └── mathFunctions.ts
```

## How to Run in VS Code
```bash
npm install
npm run build
npm start
```

## Expected Output
The terminal prints:
- primitive types examples
- function output
- array output
- interface and class output
- module import output

## Extra Explanation
This experiment combines multiple TypeScript concepts into a single practical console-based program. It is beginner-friendly and closely follows the theory in the lab manual.

## Sample Output
```text
=== TypeScript Basic Building Blocks Demo ===
Hello, Aarav! Welcome to TypeScript.
Implicit age: 21
...
Program executed successfully.
```

## Viva / Important Notes
1. TypeScript is a superset of JavaScript.
2. TypeScript adds static typing.
3. Interfaces define structure.
4. Classes are blueprints for objects.
5. Modules help split and reuse code.
