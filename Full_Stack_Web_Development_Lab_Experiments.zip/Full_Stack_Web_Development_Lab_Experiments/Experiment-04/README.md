# Experiment-04 - Demonstration of Form Development Using Angular

## Aim / Objective
To design and implement forms in Angular for capturing and validating user input efficiently.

## Required Software / Technologies
- Angular
- Node.js
- npm
- VS Code

## How to Run in VS Code
```bash
npm install
npm start
```

## Description
This experiment demonstrates both:
- Template-driven forms
- Reactive forms

## Validation Included
- required
- email
- minimum length
- 10-digit phone pattern

## Expected Output
A browser page containing two forms with validation messages and successful submission indicators.

## Extra Notes
The lab manual mentions both template-driven and reactive forms, so this implementation includes both in one project for better understanding.
