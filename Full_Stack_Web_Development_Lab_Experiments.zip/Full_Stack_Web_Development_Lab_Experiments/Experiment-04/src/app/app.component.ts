/*
Experiment Name: Demonstration of Form Development Using Angular
Purpose:
- To design and implement forms in Angular for capturing and validating user input.

Technologies Used:
- Angular
- TypeScript
- HTML
- CSS
- FormsModule
- ReactiveFormsModule

How to Run in VS Code:
1. Open Experiment-04 in VS Code.
2. Run: npm install
3. Run: npm start
4. Open http://localhost:4200

Extra Setup Required:
- None beyond Angular CLI and Node.js.
*/

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  templateStudent = {
    fullName: '',
    email: '',
    course: ''
  };

  templateSubmitted = false;

  reactiveSubmitted = false;
  reactiveForm;

  constructor(private fb: FormBuilder) {
    this.reactiveForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      city: ['', Validators.required]
    });
  }

  submitTemplateForm(): void {
    this.templateSubmitted = true;
  }

  submitReactiveForm(): void {
    this.reactiveSubmitted = true;
    this.reactiveForm.markAllAsTouched();
  }
}
