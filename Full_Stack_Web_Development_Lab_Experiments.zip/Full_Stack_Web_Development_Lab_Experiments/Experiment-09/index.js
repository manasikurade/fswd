/*
Experiment Name: Demonstrate middlewares in Express.js
Purpose:
- To demonstrate application-level middleware, route-level middleware, request logging,
  request timing, authentication check, and error handling.

Technologies Used:
- Node.js
- Express.js
- JavaScript

How to Run in VS Code:
1. Open Experiment-09 in VS Code.
2. Run: npm install
3. Run: npm start
4. Test in browser or Postman:
   - http://localhost:3000/
   - http://localhost:3000/about
   - http://localhost:3000/secure?token=lab123
   - http://localhost:3000/error

Extra Setup Required:
- No database required.
*/

const express = require('express');
const app = express();

app.use(express.json());

// Application-level middleware: logger
const myLogger = (req, res, next) => {
  console.log(`[LOGGED] ${req.method} ${req.url}`);
  next();
};

// Application-level middleware: request time
const requestTime = (req, res, next) => {
  req.requestTime = new Date().toLocaleString();
  next();
};

app.use(myLogger);
app.use(requestTime);

// Route-level middleware: simple token check
const verifyToken = (req, res, next) => {
  if (req.query.token === 'lab123') {
    return next();
  }
  return res.status(401).json({
    message: 'Unauthorized. Pass token=lab123 in query string.'
  });
};

app.get('/', (req, res) => {
  res.send(`Hello! Request received at ${req.requestTime}`);
});

app.get('/about', (req, res) => {
  res.json({
    page: 'About',
    info: 'This route demonstrates middleware execution.',
    requestTime: req.requestTime
  });
});

app.get('/secure', verifyToken, (req, res) => {
  res.json({
    message: 'Access granted to secure route.',
    requestTime: req.requestTime
  });
});

app.get('/error', (req, res, next) => {
  const err = new Error('Intentional error for demonstration.');
  next(err);
});

// Error handling middleware
app.use((err, req, res, next) => {
  res.status(500).json({
    message: 'Custom error handler caught an error.',
    error: err.message,
    requestTime: req.requestTime
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Experiment-09 server is running on http://localhost:${PORT}`);
});
