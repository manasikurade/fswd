# Experiment-09 - Demonstrate middlewares in Express.js

## Aim / Objective
To demonstrate middlewares in Express.js.

## Required Software / Technologies
- Node.js
- npm
- Express.js
- VS Code
- Postman (optional)

## How to Run
```bash
npm install
npm start
```

## Routes to Test
- `GET /`
- `GET /about`
- `GET /secure?token=lab123`
- `GET /error`

## Middleware Included
- logger middleware
- request time middleware
- route-level authentication middleware
- custom error-handling middleware

## Expected Output
The application logs requests in the terminal and returns JSON / text responses showing middleware behavior.

## Extra Notes
Order of middleware matters in Express. Middleware loaded first runs first.
