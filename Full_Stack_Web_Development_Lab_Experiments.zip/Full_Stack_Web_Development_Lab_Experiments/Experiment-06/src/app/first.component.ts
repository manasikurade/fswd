import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  standalone: true,
  template: `
    <h2>First Component</h2>
    <p>This content is displayed when the route is <code>/first-component</code>.</p>
  `
})
export class FirstComponent {}
