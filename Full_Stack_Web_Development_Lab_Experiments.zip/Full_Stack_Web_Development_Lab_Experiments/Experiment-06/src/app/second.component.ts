import { Component } from '@angular/core';

@Component({
  selector: 'app-second',
  standalone: true,
  template: `
    <h2>Second Component</h2>
    <p>This content is displayed when the route is <code>/second-component</code>.</p>
  `
})
export class SecondComponent {}
