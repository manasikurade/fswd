import { Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { FirstComponent } from './first.component';
import { SecondComponent } from './second.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'first-component', component: FirstComponent },
  { path: 'second-component', component: SecondComponent },
  { path: '**', redirectTo: '' }
];
