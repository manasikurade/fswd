/*
Experiment Name: Demonstrate page routing in Angular
Purpose:
- To demonstrate navigation between components using Angular Router.

Technologies Used:
- Angular
- Angular Router
- TypeScript
- HTML
- CSS

How to Run in VS Code:
1. Open Experiment-06 in VS Code.
2. Run: npm install
3. Run: npm start
4. Visit http://localhost:4200
5. Click the navigation links to test routing.

Extra Setup Required:
- None.
*/

import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Angular Router App';
}
