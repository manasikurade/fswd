import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `
    <h2>Home</h2>
    <p>This is the home page of the routing experiment.</p>
    <p>Use the links above to navigate to different components.</p>
  `
})
export class HomeComponent {}
