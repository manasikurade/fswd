# Experiment-06 - Demonstrate page routing in Angular

## Aim / Objective
To demonstrate routing in Angular to show the required component according to the URL.

## Required Software / Technologies
- Angular
- Angular Router
- Node.js
- npm
- VS Code

## How to Run
```bash
npm install
npm start
```

## Routes Included
- `/` - Home
- `/first-component` - First component view
- `/second-component` - Second component view

## Expected Output
Clicking navigation links loads different component views inside the `router-outlet`.

## Extra Notes
This implementation follows the lab manual idea of creating at least two components and switching between them using Angular routes.
